package com.booknook.booknook

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
