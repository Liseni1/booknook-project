import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:provider/provider.dart';
import 'main_shell.dart';
import 'providers/auth_provider.dart';
import 'providers/cart_provider.dart';
import 'providers/nav_provider.dart';
import 'screens/auth/auth_flow.dart';
import 'theme.dart';

// Kept alive for the app's lifetime: on web this forces Flutter's
// accessibility semantics tree on from startup (normally it only turns on
// after a user activates a screen reader / the "Enable accessibility"
// placeholder). That semantics tree is what lets tooling like Playwright
// find and click widgets by their accessible name, since Flutter otherwise
// renders everything to a single <canvas> with no real DOM text nodes.
// ignore: unused_element
SemanticsHandle? _semanticsHandle;

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  if (kIsWeb) {
    _semanticsHandle = RendererBinding.instance.ensureSemantics();
  }
  runApp(const BookNookApp());
}

class BookNookApp extends StatelessWidget {
  const BookNookApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()..init()),
        ChangeNotifierProvider(create: (_) => CartProvider()),
        ChangeNotifierProvider(create: (_) => NavProvider()),
      ],
      child: MaterialApp(
        title: 'BookNook',
        debugShowCheckedModeBanner: false,
        theme: buildAppTheme(),
        home: const AuthGate(),
      ),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    if (auth.loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator(color: AppColors.teal)));
    }
    if (auth.user == null) {
      return const AuthFlow();
    }
    return const MainShell();
  }
}
