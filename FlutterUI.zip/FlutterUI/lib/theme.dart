import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class AppColors {
  static const teal = Color(0xFF0B6E64);
  static const tealDark = Color(0xFF095349);
  static const background = Color(0xFFF4F8F7);
  static const card = Color(0xFFEDF4F3);
  static const border = Color(0xFFDCE6E4);
  static const textPrimary = Color(0xFF1B1F1E);
  static const textSecondary = Color(0xFF5F6D6B);
  static const peach = Color(0xFFFBD7AE);
  static const peachDark = Color(0xFFE9A662);
  static const danger = Color(0xFFC23B33);
  static const dangerBg = Color(0xFFFCEBEA);
  static const success = Color(0xFF2E7D46);
  static const successBg = Color(0xFFE8F5E9);
  static const warning = Color(0xFFB26A00);
  static const warningBg = Color(0xFFFDF1E0);
  static const info = Color(0xFF1D5FA6);
  static const infoBg = Color(0xFFE7F0FB);
  static const purple = Color(0xFF6A3FB3);
  static const purpleBg = Color(0xFFF0EAFB);
  static const white = Color(0xFFFFFFFF);
  static const infoBoxBg = Color(0xFFF0F3F2);
  static const placeholder = Color(0xFF8A9491);
}

class AppSpacing {
  static const xs = 4.0;
  static const sm = 8.0;
  static const md = 12.0;
  static const lg = 16.0;
  static const xl = 24.0;
}

class AppRadius {
  static const sm = 8.0;
  static const md = 12.0;
  static const lg = 16.0;
  static const pill = 999.0;
}

final _lkrFormat = NumberFormat.currency(locale: 'en_US', symbol: 'LKR ', decimalDigits: 2);

String formatLKR(num amount) => _lkrFormat.format(amount);

const coverColors = [
  Color(0xFF7FE3E0),
  Color(0xFFF7C5A0),
  Color(0xFFC6E2A0),
  Color(0xFFF5B8C4),
  Color(0xFFB9C8F0),
  Color(0xFFF5E28A),
];

Color coverColorFor(String id) {
  int hash = 0;
  for (final ch in id.codeUnits) {
    hash = (hash * 31 + ch) % coverColors.length;
  }
  return coverColors[hash.abs() % coverColors.length];
}

ThemeData buildAppTheme() {
  return ThemeData(
    useMaterial3: true,
    scaffoldBackgroundColor: AppColors.background,
    colorScheme: ColorScheme.fromSeed(seedColor: AppColors.teal, primary: AppColors.teal),
    fontFamily: 'Roboto',
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.teal,
      foregroundColor: AppColors.white,
      elevation: 0,
    ),
  );
}
