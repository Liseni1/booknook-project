import 'dart:convert';
import 'package:http/http.dart' as http;
import 'api_config.dart';

/// Thrown for any non-2xx API response. Carries the backend's field-level
/// validation errors (if any) so screens can render them inline, matching
/// the reference UI's red-outline/error-icon style instead of a generic
/// alert() popup.
class ApiException implements Exception {
  final String message;
  final int? status;
  final Map<String, String>? errors;
  ApiException(this.message, {this.status, this.errors});

  /// Convenience: the first field error, or the top-level message.
  String get firstError => errors != null && errors!.isNotEmpty ? errors!.values.first : message;

  @override
  String toString() => message;
}

class ApiClient {
  String? _token;

  void setToken(String? token) {
    _token = token;
  }

  Uri _uri(String path, [Map<String, dynamic>? query]) {
    final full = '$kApiBaseUrl$path';
    if (query == null || query.isEmpty) return Uri.parse(full);
    final filtered = <String, String>{};
    query.forEach((k, v) {
      if (v != null && v.toString().isNotEmpty) filtered[k] = v.toString();
    });
    final base = Uri.parse(full);
    return base.replace(queryParameters: filtered.isEmpty ? null : filtered);
  }

  Future<dynamic> _request(
    String path, {
    String method = 'GET',
    Map<String, dynamic>? body,
    Map<String, dynamic>? query,
    bool auth = true,
  }) async {
    final headers = <String, String>{'Content-Type': 'application/json'};
    if (auth && _token != null) headers['Authorization'] = 'Bearer $_token';

    http.Response res;
    try {
      final uri = _uri(path, query);
      final encodedBody = body != null ? jsonEncode(body) : null;
      switch (method) {
        case 'POST':
          res = await http.post(uri, headers: headers, body: encodedBody);
          break;
        case 'PUT':
          res = await http.put(uri, headers: headers, body: encodedBody);
          break;
        case 'PATCH':
          res = await http.patch(uri, headers: headers, body: encodedBody);
          break;
        case 'DELETE':
          res = await http.delete(uri, headers: headers, body: encodedBody);
          break;
        default:
          res = await http.get(uri, headers: headers);
      }
    } catch (e, st) {
      print('API ERROR: $e');
      print(st);
      throw ApiException('Could not reach the BookNook server. Check your connection and try again.');
    }

    dynamic data;
    if (res.body.isNotEmpty) {
      try {
        data = jsonDecode(res.body);
      } catch (_) {
        data = null;
      }
    }

    if (res.statusCode < 200 || res.statusCode >= 300) {
      String msg = 'Something went wrong. Please try again.';
      Map<String, String>? errors;
      if (data is Map) {
        if (data['error'] != null) msg = data['error'].toString();
        if (data['errors'] is Map) {
          errors = (data['errors'] as Map).map((k, v) => MapEntry(k.toString(), v.toString()));
        }
      }
      throw ApiException(msg, status: res.statusCode, errors: errors);
    }
    return data;
  }

  // ---- Auth ----
  Future<Map<String, dynamic>> register({required String name, required String email, required String password}) =>
      _request('/auth/register', method: 'POST', body: {'name': name, 'email': email, 'password': password}, auth: false)
          .then((d) => d as Map<String, dynamic>);

  Future<Map<String, dynamic>> login({required String email, required String password}) =>
      _request('/auth/login', method: 'POST', body: {'email': email, 'password': password}, auth: false)
          .then((d) => d as Map<String, dynamic>);

  // ---- Books ----
  Future<Map<String, dynamic>> getBooks({String? search, String? category}) =>
      _request('/books', query: {'search': search, 'category': category}, auth: false).then((d) => d as Map<String, dynamic>);

  Future<Map<String, dynamic>> getBook(String id) =>
      _request('/books/$id', auth: false).then((d) => d as Map<String, dynamic>);

  Future<Map<String, dynamic>> createBook(Map<String, dynamic> payload) =>
      _request('/books', method: 'POST', body: payload).then((d) => d as Map<String, dynamic>);

  Future<Map<String, dynamic>> updateBook(String id, Map<String, dynamic> payload) =>
      _request('/books/$id', method: 'PUT', body: payload).then((d) => d as Map<String, dynamic>);

  Future<void> deleteBook(String id) => _request('/books/$id', method: 'DELETE');

  // ---- Cart ----
  Future<Map<String, dynamic>> getCart() => _request('/cart').then((d) => d as Map<String, dynamic>);

  Future<Map<String, dynamic>> addToCart(String bookId, int quantity) =>
      _request('/cart/items', method: 'POST', body: {'bookId': bookId, 'quantity': quantity}).then((d) => d as Map<String, dynamic>);

  Future<Map<String, dynamic>> updateCartItem(String bookId, int quantity) =>
      _request('/cart/items/$bookId', method: 'PUT', body: {'quantity': quantity}).then((d) => d as Map<String, dynamic>);

  Future<Map<String, dynamic>> removeCartItem(String bookId) =>
      _request('/cart/items/$bookId', method: 'DELETE').then((d) => d as Map<String, dynamic>);

  // ---- Orders ----
  Future<Map<String, dynamic>> checkout() => _request('/orders', method: 'POST', body: {}).then((d) => d as Map<String, dynamic>);

  Future<Map<String, dynamic>> getOrders({String? status}) =>
      _request('/orders', query: {'status': status}).then((d) => d as Map<String, dynamic>);

  Future<Map<String, dynamic>> getOrder(String id) => _request('/orders/$id').then((d) => d as Map<String, dynamic>);

  Future<Map<String, dynamic>> updateOrderStatus(String id, String status) =>
      _request('/orders/$id/status', method: 'PATCH', body: {'status': status}).then((d) => d as Map<String, dynamic>);

  // ---- Users ----
  Future<Map<String, dynamic>> getUsers() => _request('/users').then((d) => d as Map<String, dynamic>);

  Future<Map<String, dynamic>> updateUserRole(String id, String role) =>
      _request('/users/$id/role', method: 'PATCH', body: {'role': role}).then((d) => d as Map<String, dynamic>);
}

final apiClient = ApiClient();
