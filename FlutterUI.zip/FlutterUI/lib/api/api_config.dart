/// Base URL for the BookNook backend REST API.
///
/// IMPORTANT: this is the developer machine's LAN IP address (Wi-Fi adapter),
/// not `localhost`. On a real Android phone, `http://localhost:4000` resolves
/// to the PHONE itself, not the PC running the backend -- that mismatch was
/// the root cause of the earlier React Native prototype's APK "not working"
/// (it installed fine but could never reach the API). Using the PC's LAN IP
/// lets a phone on the same Wi-Fi network reach the backend.
///
/// If this machine's IP address changes (different network, DHCP lease
/// renewal, etc.), update it here and rebuild the APK.
///
/// Note: `10.0.2.2` is a special alias that only works from inside the
/// Android *emulator* to reach the host machine's `localhost` -- it is not
/// used here since we're targeting a real device over Wi-Fi, but it's worth
/// knowing about if this project is later run in an emulator instead.
const String kApiBaseUrl = 'http://10.0.2.2:4000/api';
