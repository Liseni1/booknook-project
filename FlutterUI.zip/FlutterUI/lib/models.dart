class Book {
  final String id;
  final String title;
  final String author;
  final String isbn;
  final String category;
  final num price;
  final int stock;
  final String description;
  final String coverLetter;

  Book({
    required this.id,
    required this.title,
    required this.author,
    required this.isbn,
    required this.category,
    required this.price,
    required this.stock,
    required this.description,
    required this.coverLetter,
  });

  factory Book.fromJson(Map<String, dynamic> j) => Book(
        id: j['id'].toString(),
        title: j['title'] ?? '',
        author: j['author'] ?? '',
        isbn: j['isbn']?.toString() ?? '',
        category: j['category'] ?? '',
        price: j['price'] ?? 0,
        stock: (j['stock'] ?? 0) as int,
        description: j['description'] ?? '',
        coverLetter: j['coverLetter'] ?? (j['title'] ?? '?').toString().substring(0, 1).toUpperCase(),
      );
}

class CartItem {
  final String bookId;
  final String title;
  final String author;
  final num price;
  final int quantity;
  final int stock;

  CartItem({
    required this.bookId,
    required this.title,
    required this.author,
    required this.price,
    required this.quantity,
    required this.stock,
  });

  factory CartItem.fromJson(Map<String, dynamic> j) => CartItem(
        bookId: j['bookId'].toString(),
        title: j['title'] ?? '',
        author: j['author'] ?? '',
        price: j['price'] ?? 0,
        quantity: (j['quantity'] ?? 0) as int,
        stock: (j['stock'] ?? 0) as int,
      );
}

class OrderItem {
  final String bookId;
  final String title;
  final num price;
  final int quantity;

  OrderItem({required this.bookId, required this.title, required this.price, required this.quantity});

  factory OrderItem.fromJson(Map<String, dynamic> j) => OrderItem(
        bookId: j['bookId'].toString(),
        title: j['title'] ?? '',
        price: j['price'] ?? 0,
        quantity: (j['quantity'] ?? 0) as int,
      );
}

class BookOrder {
  final String id;
  final String userId;
  final String customerName;
  final List<OrderItem> items;
  final num total;
  final String status;
  final String createdAt;

  BookOrder({
    required this.id,
    required this.userId,
    required this.customerName,
    required this.items,
    required this.total,
    required this.status,
    required this.createdAt,
  });

  factory BookOrder.fromJson(Map<String, dynamic> j) => BookOrder(
        id: j['id'].toString(),
        userId: j['userId']?.toString() ?? '',
        customerName: j['customerName'] ?? '',
        items: ((j['items'] as List?) ?? []).map((e) => OrderItem.fromJson(e as Map<String, dynamic>)).toList(),
        total: j['total'] ?? 0,
        status: j['status'] ?? 'Pending',
        createdAt: j['createdAt']?.toString() ?? '',
      );
}

class AppUser {
  final String id;
  final String name;
  final String email;
  final String role;

  AppUser({required this.id, required this.name, required this.email, required this.role});

  factory AppUser.fromJson(Map<String, dynamic> j) => AppUser(
        id: j['id'].toString(),
        name: j['name'] ?? '',
        email: j['email'] ?? '',
        role: j['role'] ?? 'customer',
      );

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'email': email, 'role': role};
}
