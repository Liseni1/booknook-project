import 'package:flutter/foundation.dart';

/// Tracks which bottom-tab is selected, addressed by name ('browse',
/// 'catalogue', 'orders', 'users', 'profile') rather than index, since the
/// set of visible tabs depends on the signed-in user's role.
class NavProvider extends ChangeNotifier {
  String selected = 'browse';

  void select(String tab) {
    selected = tab;
    notifyListeners();
  }
}
