import 'package:flutter/foundation.dart';
import '../api/api_client.dart';
import '../models.dart';

class CartProvider extends ChangeNotifier {
  List<CartItem> items = [];
  num total = 0;
  bool loading = false;

  int get count => items.fold(0, (sum, it) => sum + it.quantity);

  Future<void> refresh() async {
    loading = true;
    notifyListeners();
    try {
      final data = await apiClient.getCart();
      items = ((data['items'] as List?) ?? []).map((e) => CartItem.fromJson(e as Map<String, dynamic>)).toList();
      total = data['total'] ?? 0;
    } catch (_) {
      // Not signed in yet or a transient error; leave cart as-is.
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  void clear() {
    items = [];
    total = 0;
    notifyListeners();
  }
}
