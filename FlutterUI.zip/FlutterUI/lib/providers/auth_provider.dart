import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../api/api_client.dart';
import '../models.dart';

const _storageKey = 'booknook.auth';

class AuthProvider extends ChangeNotifier {
  AppUser? user;
  String? token;
  bool loading = true;

  Future<void> init() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_storageKey);
      if (raw != null) {
        final saved = jsonDecode(raw) as Map<String, dynamic>;
        token = saved['token'] as String?;
        user = AppUser.fromJson(saved['user'] as Map<String, dynamic>);
        apiClient.setToken(token);
      }
    } catch (_) {
      // Corrupt or missing storage; treat as signed out.
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  Future<void> _persist(String nextToken, AppUser nextUser) async {
    token = nextToken;
    user = nextUser;
    apiClient.setToken(nextToken);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_storageKey, jsonEncode({'token': nextToken, 'user': nextUser.toJson()}));
    notifyListeners();
  }

  Future<void> login(String email, String password) async {
    final data = await apiClient.login(email: email, password: password);
    await _persist(data['token'] as String, AppUser.fromJson(data['user'] as Map<String, dynamic>));
  }

  Future<void> register(String name, String email, String password) async {
    final data = await apiClient.register(name: name, email: email, password: password);
    await _persist(data['token'] as String, AppUser.fromJson(data['user'] as Map<String, dynamic>));
  }

  Future<void> signOut() async {
    token = null;
    user = null;
    apiClient.setToken(null);
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_storageKey);
    notifyListeners();
  }
}
