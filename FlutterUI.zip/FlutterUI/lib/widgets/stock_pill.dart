import 'package:flutter/material.dart';
import '../theme.dart';

enum StockVariant { browse, catalogue }

class StockPill extends StatelessWidget {
  final int stock;
  final StockVariant variant;

  const StockPill({super.key, required this.stock, this.variant = StockVariant.catalogue});

  @override
  Widget build(BuildContext context) {
    String label;
    Color fg, bg, border;

    if (stock == 0) {
      label = 'Out of stock';
      fg = AppColors.danger;
      bg = AppColors.dangerBg;
      border = AppColors.danger;
    } else if (stock <= 3) {
      label = variant == StockVariant.browse ? (stock == 1 ? 'Only 1 left' : 'Only $stock left') : '$stock in stock';
      fg = AppColors.warning;
      bg = AppColors.warningBg;
      border = AppColors.warning;
    } else {
      label = '$stock in stock';
      fg = AppColors.success;
      bg = AppColors.successBg;
      border = AppColors.success;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        border: Border.all(color: border),
        borderRadius: BorderRadius.circular(AppRadius.pill),
      ),
      child: Text(label, style: TextStyle(color: fg, fontSize: 12, fontWeight: FontWeight.w700)),
    );
  }
}
