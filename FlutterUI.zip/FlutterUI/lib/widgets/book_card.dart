import 'package:flutter/material.dart';
import '../models.dart';
import '../theme.dart';
import 'stock_pill.dart';

class BookCard extends StatelessWidget {
  final Book book;
  final VoidCallback onTap;

  const BookCard({super.key, required this.book, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: AppSpacing.md),
        padding: const EdgeInsets.all(AppSpacing.md),
        decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(AppRadius.lg)),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 56,
              height: 78,
              alignment: Alignment.center,
              margin: const EdgeInsets.only(right: AppSpacing.md),
              decoration: BoxDecoration(color: coverColorFor(book.id), borderRadius: BorderRadius.circular(AppRadius.sm)),
              child: Text(book.coverLetter, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: Color(0xFF1B1F1E))),
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Text(
                          book.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                        ),
                      ),
                      const Icon(Icons.chevron_right, size: 18, color: AppColors.textSecondary),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(book.author, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      const Icon(Icons.local_offer_outlined, size: 13, color: AppColors.textSecondary),
                      const SizedBox(width: 4),
                      Text(book.category, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(formatLKR(book.price), style: const TextStyle(color: AppColors.teal, fontWeight: FontWeight.w800, fontSize: 15)),
                      StockPill(stock: book.stock, variant: StockVariant.browse),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
