import 'package:flutter/material.dart';
import '../theme.dart';

class CategoryChip extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onPressed;
  final Key? chipKey;

  const CategoryChip({super.key, required this.label, required this.active, required this.onPressed, this.chipKey});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: AppSpacing.sm),
      child: GestureDetector(
        key: chipKey,
        onTap: onPressed,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: AppSpacing.sm),
          decoration: BoxDecoration(
            color: active ? AppColors.peach : AppColors.white,
            border: Border.all(color: active ? AppColors.peachDark : AppColors.border),
            borderRadius: BorderRadius.circular(AppRadius.pill),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: active ? AppColors.tealDark : AppColors.textPrimary,
              fontWeight: active ? FontWeight.w700 : FontWeight.w500,
              fontSize: 13,
            ),
          ),
        ),
      ),
    );
  }
}
