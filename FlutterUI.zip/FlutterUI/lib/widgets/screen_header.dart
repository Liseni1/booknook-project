import 'package:flutter/material.dart';
import '../theme.dart';

class ScreenHeader extends StatelessWidget {
  final String title;
  final IconData icon;
  final Widget? right;

  const ScreenHeader({super.key, required this.title, this.icon = Icons.menu_book_outlined, this.right});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.teal,
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + AppSpacing.md,
        bottom: AppSpacing.lg,
        left: AppSpacing.lg,
        right: AppSpacing.lg,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(icon, size: 22, color: AppColors.white),
              const SizedBox(width: AppSpacing.sm),
              Text(title, style: const TextStyle(color: AppColors.white, fontSize: 24, fontWeight: FontWeight.w700)),
            ],
          ),
          if (right != null) right!,
        ],
      ),
    );
  }
}
