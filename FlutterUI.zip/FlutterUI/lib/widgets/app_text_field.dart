import 'package:flutter/material.dart';
import '../theme.dart';

/// Text field matching the reference design: rounded teal outline, optional
/// leading icon, and on error a red outline + red exclamation icon + red
/// helper text below -- shown inline, never as a popup.
class AppTextField extends StatelessWidget {
  final String label;
  final IconData? icon;
  final String? error;
  final String? helperText;
  final int? maxLength;
  final bool showCount;
  final TextEditingController controller;
  final bool obscureText;
  final TextInputType? keyboardType;
  final int maxLines;
  final ValueChanged<String>? onChanged;
  final FocusNode? focusNode;

  const AppTextField({
    super.key,
    required this.label,
    required this.controller,
    this.icon,
    this.error,
    this.helperText,
    this.maxLength,
    this.showCount = false,
    this.obscureText = false,
    this.keyboardType,
    this.maxLines = 1,
    this.onChanged,
    this.focusNode,
  });

  @override
  Widget build(BuildContext context) {
    final hasError = error != null && error!.isNotEmpty;
    final borderColor = hasError ? AppColors.danger : AppColors.teal;

    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.md),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: maxLines > 1 ? 100 : 52,
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md),
            decoration: BoxDecoration(
              color: AppColors.white,
              borderRadius: BorderRadius.circular(AppRadius.lg),
              border: Border.all(color: borderColor, width: 1.5),
            ),
            child: Row(
              crossAxisAlignment: maxLines > 1 ? CrossAxisAlignment.start : CrossAxisAlignment.center,
              children: [
                if (icon != null) ...[
                  Padding(
                    padding: const EdgeInsets.only(top: 14),
                    child: Icon(icon, size: 20, color: hasError ? AppColors.danger : AppColors.teal),
                  ),
                  const SizedBox(width: AppSpacing.sm),
                ],
                Expanded(
                  child: TextField(
                    controller: controller,
                    focusNode: focusNode,
                    obscureText: obscureText,
                    keyboardType: keyboardType,
                    maxLength: maxLength,
                    maxLines: maxLines,
                    onChanged: onChanged,
                    style: TextStyle(fontSize: 16, color: hasError ? AppColors.danger : AppColors.textPrimary),
                    decoration: InputDecoration(
                      hintText: label,
                      hintStyle: TextStyle(color: hasError ? const Color(0xFFD98B85) : AppColors.placeholder),
                      border: InputBorder.none,
                      counterText: '',
                      isDense: true,
                      contentPadding: EdgeInsets.symmetric(vertical: maxLines > 1 ? 12 : 0),
                    ),
                  ),
                ),
                if (hasError) const Icon(Icons.error, size: 20, color: AppColors.danger),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 4, left: 4, right: 4),
            child: Row(
              children: [
                Expanded(
                  child: hasError
                      ? Text(error!, style: const TextStyle(color: AppColors.danger, fontSize: 12))
                      : (helperText != null
                          ? Text(helperText!, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12))
                          : const SizedBox.shrink()),
                ),
                if (showCount && maxLength != null)
                  ValueListenableBuilder<TextEditingValue>(
                    valueListenable: controller,
                    builder: (context, value, _) => Text(
                      '${value.text.length}/$maxLength',
                      style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
