import 'package:flutter/material.dart';
import '../theme.dart';

enum ButtonVariant { primary, outline, danger }

class PrimaryButton extends StatelessWidget {
  final String title;
  final VoidCallback? onPressed;
  final bool loading;
  final bool disabled;
  final ButtonVariant variant;
  final EdgeInsetsGeometry? margin;
  final double? width;

  const PrimaryButton({
    super.key,
    required this.title,
    required this.onPressed,
    this.loading = false,
    this.disabled = false,
    this.variant = ButtonVariant.primary,
    this.margin,
    this.width,
  });

  @override
  Widget build(BuildContext context) {
    final isOutline = variant == ButtonVariant.outline;
    final isDanger = variant == ButtonVariant.danger;
    final isDisabled = disabled || loading;

    Color bg = AppColors.teal;
    if (isOutline) bg = Colors.transparent;
    if (isDanger) bg = AppColors.danger;

    final child = Container(
      height: 52,
      width: width,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(AppRadius.lg),
        border: isOutline ? Border.all(color: AppColors.teal, width: 1.5) : null,
      ),
      child: loading
          ? SizedBox(
              width: 22,
              height: 22,
              child: CircularProgressIndicator(strokeWidth: 2.4, color: isOutline ? AppColors.teal : AppColors.white),
            )
          : Text(
              title,
              style: TextStyle(
                color: isOutline ? AppColors.teal : AppColors.white,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
    );

    return Container(
      margin: margin,
      child: Opacity(
        opacity: isDisabled ? 0.5 : 1,
        child: GestureDetector(
          onTap: isDisabled ? null : onPressed,
          child: child,
        ),
      ),
    );
  }
}
