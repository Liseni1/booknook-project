import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../theme.dart';
import '../../widgets/app_text_field.dart';
import '../../widgets/primary_button.dart';

class SignInScreen extends StatefulWidget {
  final VoidCallback onCreateAccount;
  const SignInScreen({super.key, required this.onCreateAccount});

  @override
  State<SignInScreen> createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  final Set<String> _touched = {};
  bool _submitting = false;
  String _serverError = '';

  Map<String, String> get _errors {
    final errors = <String, String>{};
    if (_email.text.trim().isEmpty) errors['email'] = 'Email address is required.';
    if (_password.text.isEmpty) errors['password'] = 'Password is required.';
    return errors;
  }

  String? _show(String field) => (_touched.contains(field) || _touched.contains('submitted')) ? _errors[field] : null;

  Future<void> _onSubmit() async {
    setState(() {
      _touched.addAll(['email', 'password', 'submitted']);
      _serverError = '';
    });
    if (_errors.isNotEmpty) return;
    setState(() => _submitting = true);
    try {
      await context.read<AuthProvider>().login(_email.text.trim(), _password.text);
    } catch (e) {
      setState(() => _serverError = e.toString());
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(AppSpacing.lg),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: AppSpacing.md),
              Row(
                children: const [
                  Icon(Icons.menu_book_outlined, size: 30, color: AppColors.teal),
                  SizedBox(width: AppSpacing.sm),
                  Text('BookNook', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.teal)),
                ],
              ),
              const SizedBox(height: AppSpacing.xl),
              const Text('Welcome back', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
              const SizedBox(height: 4),
              const Text('Sign in to continue browsing and ordering',
                  style: TextStyle(fontSize: 14, color: AppColors.textSecondary)),
              const SizedBox(height: AppSpacing.lg),
              AppTextField(
                label: 'Email address',
                icon: Icons.mail_outline,
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                error: _show('email'),
                onChanged: (_) => setState(() {}),
              ),
              AppTextField(
                label: 'Password',
                icon: Icons.lock_outline,
                controller: _password,
                obscureText: true,
                error: _show('password'),
                onChanged: (_) => setState(() {}),
              ),
              if (_serverError.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: AppSpacing.md),
                  child: Text(_serverError, style: const TextStyle(color: AppColors.danger, fontSize: 13)),
                ),
              PrimaryButton(title: 'Sign in', onPressed: _onSubmit, loading: _submitting, width: double.infinity),
              Padding(
                padding: const EdgeInsets.only(top: AppSpacing.lg),
                child: Center(
                  child: GestureDetector(
                    onTap: widget.onCreateAccount,
                    child: const Text('New to BookNook? Create an account',
                        style: TextStyle(color: AppColors.teal, fontWeight: FontWeight.w700, fontSize: 15)),
                  ),
                ),
              ),
              Container(
                margin: const EdgeInsets.only(top: AppSpacing.xl),
                padding: const EdgeInsets.all(AppSpacing.md),
                decoration: BoxDecoration(color: AppColors.infoBoxBg, borderRadius: BorderRadius.circular(12)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text('Demo accounts (password: Passw0rd!)',
                        style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.textPrimary, fontSize: 13)),
                    SizedBox(height: 6),
                    Text('Customer — customer@booknook.lk', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                    Text('Store Staff — staff@booknook.lk', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                    Text('Administrator — admin@booknook.lk', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
