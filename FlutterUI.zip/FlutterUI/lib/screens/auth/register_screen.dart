import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../api/api_client.dart';
import '../../providers/auth_provider.dart';
import '../../theme.dart';
import '../../widgets/app_text_field.dart';
import '../../widgets/primary_button.dart';

class RegisterScreen extends StatefulWidget {
  final VoidCallback onBack;
  final VoidCallback onSignIn;
  const RegisterScreen({super.key, required this.onBack, required this.onSignIn});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _confirmPassword = TextEditingController();
  final Set<String> _touched = {};
  bool _submitting = false;
  String _serverError = '';

  Map<String, String> get _errors {
    final errors = <String, String>{};
    final name = _name.text.trim();
    if (name.isEmpty) {
      errors['name'] = 'Full name is required.';
    } else if (name.length > 60) {
      errors['name'] = 'Full name must be 60 characters or fewer.';
    }

    final email = _email.text.trim();
    if (email.isEmpty) {
      errors['email'] = 'Email address is required.';
    } else if (!RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$').hasMatch(email)) {
      errors['email'] = 'Enter a valid email address.';
    }

    final password = _password.text;
    if (password.isEmpty) {
      errors['password'] = 'Password is required.';
    } else if (password.length < 8 || !RegExp(r'\d').hasMatch(password)) {
      errors['password'] = 'Password must be at least 8 characters and include a number.';
    }

    final confirm = _confirmPassword.text;
    if (confirm.isEmpty) {
      errors['confirmPassword'] = 'Please re-enter your password.';
    } else if (confirm != password) {
      errors['confirmPassword'] = 'Passwords do not match.';
    }

    return errors;
  }

  String? _show(String field) => (_touched.contains(field) || _touched.contains('submitted')) ? _errors[field] : null;

  Future<void> _onSubmit() async {
    setState(() {
      _touched.addAll(['name', 'email', 'password', 'confirmPassword', 'submitted']);
      _serverError = '';
    });
    if (_errors.isNotEmpty) return;
    setState(() => _submitting = true);
    try {
      await context.read<AuthProvider>().register(_name.text.trim(), _email.text.trim(), _password.text);
    } on ApiException catch (e) {
      setState(() => _serverError = e.errors?['email'] ?? e.errors?['name'] ?? e.errors?['password'] ?? 'Please check the form and try again.');
    } catch (e) {
      setState(() => _serverError = e.toString());
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(AppSpacing.lg),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                key: const Key('back-button'),
                onTap: widget.onBack,
                child: const Padding(
                  padding: EdgeInsets.only(bottom: AppSpacing.lg),
                  child: Icon(Icons.arrow_back, size: 24, color: AppColors.teal, semanticLabel: 'Back'),
                ),
              ),
              const Text('Create your account', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
              const SizedBox(height: 4),
              const Padding(
                padding: EdgeInsets.only(bottom: AppSpacing.lg),
                child: Text('Join BookNook and start ordering today', style: TextStyle(fontSize: 14, color: AppColors.textSecondary)),
              ),
              AppTextField(
                label: 'Full name',
                icon: Icons.person_outline,
                controller: _name,
                maxLength: 60,
                showCount: true,
                error: _show('name'),
                onChanged: (_) => setState(() {}),
              ),
              AppTextField(
                label: 'Email address',
                icon: Icons.mail_outline,
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                error: _show('email'),
                onChanged: (_) => setState(() {}),
              ),
              AppTextField(
                label: 'Password',
                icon: Icons.lock_outline,
                controller: _password,
                obscureText: true,
                error: _show('password'),
                helperText: _show('password') == null ? 'At least 8 characters, including a number.' : null,
                onChanged: (_) => setState(() {}),
              ),
              AppTextField(
                label: 'Confirm password',
                icon: Icons.lock_outline,
                controller: _confirmPassword,
                obscureText: true,
                error: _show('confirmPassword'),
                onChanged: (_) => setState(() {}),
              ),
              if (_serverError.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: AppSpacing.md),
                  child: Text(_serverError, style: const TextStyle(color: AppColors.danger, fontSize: 13)),
                ),
              PrimaryButton(title: 'Create account', onPressed: _onSubmit, loading: _submitting, width: double.infinity),
              Padding(
                padding: const EdgeInsets.only(top: AppSpacing.lg),
                child: Center(
                  child: GestureDetector(
                    onTap: widget.onSignIn,
                    child: const Text('Already registered? Sign in',
                        style: TextStyle(color: AppColors.teal, fontWeight: FontWeight.w700, fontSize: 15)),
                  ),
                ),
              ),
              Container(
                margin: const EdgeInsets.only(top: AppSpacing.xl),
                padding: const EdgeInsets.all(AppSpacing.md),
                decoration: BoxDecoration(color: AppColors.infoBoxBg, borderRadius: BorderRadius.circular(12)),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Icon(Icons.verified_user_outlined, size: 20, color: AppColors.tealDark),
                    SizedBox(width: AppSpacing.sm),
                    Expanded(
                      child: Text(
                        'New accounts are created with the Customer role. Staff and Administrator roles are assigned by an administrator.',
                        style: TextStyle(color: AppColors.textSecondary, fontSize: 13, height: 1.3),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
