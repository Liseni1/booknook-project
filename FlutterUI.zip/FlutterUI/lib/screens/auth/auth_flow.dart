import 'package:flutter/material.dart';
import 'register_screen.dart';
import 'sign_in_screen.dart';

class AuthFlow extends StatefulWidget {
  const AuthFlow({super.key});

  @override
  State<AuthFlow> createState() => _AuthFlowState();
}

class _AuthFlowState extends State<AuthFlow> {
  bool _showRegister = false;

  @override
  Widget build(BuildContext context) {
    if (_showRegister) {
      return RegisterScreen(
        onBack: () => setState(() => _showRegister = false),
        onSignIn: () => setState(() => _showRegister = false),
      );
    }
    return SignInScreen(onCreateAccount: () => setState(() => _showRegister = true));
  }
}
