import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../api/api_client.dart';
import '../../models.dart';
import '../../providers/cart_provider.dart';
import '../../theme.dart';
import '../../widgets/app_search_bar.dart';
import '../../widgets/book_card.dart';
import '../../widgets/category_chip.dart';
import '../../widgets/screen_header.dart';
import '../cart/cart_screen.dart';
import 'book_detail_screen.dart';

const kCategories = ['All', 'Biography', 'Fiction', 'Finance', 'Programming', 'Self Help'];

class BrowseScreen extends StatefulWidget {
  const BrowseScreen({super.key});

  @override
  State<BrowseScreen> createState() => _BrowseScreenState();
}

class _BrowseScreenState extends State<BrowseScreen> with AutomaticKeepAliveClientMixin {
  final _search = TextEditingController();
  String _category = 'All';
  List<Book> _books = [];
  bool _loading = true;
  String _error = '';

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _load();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<CartProvider>().refresh());
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = '';
    });
    try {
      final data = await apiClient.getBooks(
        search: _search.text.isEmpty ? null : _search.text,
        category: _category == 'All' ? null : _category,
      );
      setState(() {
        _books = ((data['books'] as List?) ?? []).map((e) => Book.fromJson(e as Map<String, dynamic>)).toList();
      });
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final cart = context.watch<CartProvider>();
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          ScreenHeader(
            title: 'Browse',
            right: _CartButton(count: cart.count),
          ),
          AppSearchBar(controller: _search, onChanged: (_) => _load()),
          SizedBox(
            height: 52,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.sm),
              children: kCategories
                  .map((c) => CategoryChip(
                        chipKey: Key('category-chip-$c'),
                        label: c,
                        active: c == _category,
                        onPressed: () {
                          setState(() => _category = c);
                          _load();
                        },
                      ))
                  .toList(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: AppSpacing.lg, right: AppSpacing.lg, bottom: AppSpacing.sm),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text('${_books.length} book(s) found', style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
            ),
          ),
          if (_error.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
              child: Text(_error, style: const TextStyle(color: AppColors.danger)),
            ),
          Expanded(
            child: RefreshIndicator(
              onRefresh: _load,
              color: AppColors.teal,
              child: _loading && _books.isEmpty
                  ? const Center(child: CircularProgressIndicator(color: AppColors.teal))
                  : (_books.isEmpty
                      ? ListView(
                          children: const [
                            Padding(
                              padding: EdgeInsets.only(top: AppSpacing.xl),
                              child: Center(child: Text('No books match your search.', style: TextStyle(color: AppColors.textSecondary))),
                            ),
                          ],
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(AppSpacing.lg),
                          itemCount: _books.length,
                          itemBuilder: (context, i) {
                            final book = _books[i];
                            return BookCard(
                              book: book,
                              onTap: () => Navigator.of(context)
                                  .push(MaterialPageRoute(builder: (_) => BookDetailScreen(bookId: book.id))),
                            );
                          },
                        )),
            ),
          ),
        ],
      ),
    );
  }
}

class _CartButton extends StatelessWidget {
  final int count;
  const _CartButton({required this.count});

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'Cart',
      button: true,
      excludeSemantics: true,
      child: GestureDetector(
        key: const Key('cart-button'),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CartScreen())),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            const Icon(Icons.shopping_cart_outlined, size: 24, color: AppColors.white),
            if (count > 0)
              Positioned(
                top: -2,
                right: -2,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
                  decoration: BoxDecoration(color: AppColors.danger, borderRadius: BorderRadius.circular(10)),
                  alignment: Alignment.center,
                  child: Text('$count', style: const TextStyle(color: AppColors.white, fontSize: 10, fontWeight: FontWeight.w700)),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
