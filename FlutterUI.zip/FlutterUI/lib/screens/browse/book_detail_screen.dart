import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../api/api_client.dart';
import '../../models.dart';
import '../../providers/cart_provider.dart';
import '../../theme.dart';
import '../../widgets/primary_button.dart';
import '../../widgets/stock_pill.dart';
import '../cart/cart_screen.dart';

class BookDetailScreen extends StatefulWidget {
  final String bookId;
  const BookDetailScreen({super.key, required this.bookId});

  @override
  State<BookDetailScreen> createState() => _BookDetailScreenState();
}

class _BookDetailScreenState extends State<BookDetailScreen> {
  Book? _book;
  int _quantity = 1;
  bool _adding = false;
  bool _added = false;
  String _error = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final data = await apiClient.getBook(widget.bookId);
      setState(() => _book = Book.fromJson(data['book'] as Map<String, dynamic>));
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    }
  }

  Future<void> _onAdd() async {
    setState(() {
      _adding = true;
      _error = '';
      _added = false;
    });
    final cart = context.read<CartProvider>();
    try {
      await apiClient.addToCart(_book!.id, _quantity);
      await cart.refresh();
      setState(() => _added = true);
    } on ApiException catch (e) {
      setState(() => _error = e.errors?['quantity'] ?? e.message);
    } finally {
      if (mounted) setState(() => _adding = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final book = _book;
    if (book == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator(color: AppColors.teal)));
    }
    final outOfStock = book.stock == 0;

    return Scaffold(
      backgroundColor: AppColors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(AppSpacing.lg),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                key: const Key('back-button'),
                onTap: () => Navigator.of(context).pop(),
                child: const Padding(
                  padding: EdgeInsets.only(bottom: AppSpacing.lg),
                  child: Icon(Icons.arrow_back, size: 24, color: AppColors.teal, semanticLabel: 'Back'),
                ),
              ),
              Container(
                width: 120,
                height: 168,
                alignment: Alignment.center,
                margin: const EdgeInsets.only(bottom: AppSpacing.lg),
                decoration: BoxDecoration(color: const Color(0xFF7FE3E0), borderRadius: BorderRadius.circular(AppRadius.md)),
                child: Text(book.coverLetter, style: const TextStyle(fontSize: 52, fontWeight: FontWeight.w800, color: Color(0xFF112233))),
              ),
              Text(book.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
              const SizedBox(height: 4),
              Text(book.author, style: const TextStyle(fontSize: 15, color: AppColors.textSecondary)),
              const SizedBox(height: AppSpacing.md),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.local_offer_outlined, size: 13, color: AppColors.textSecondary),
                      const SizedBox(width: 4),
                      Text(book.category, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                    ],
                  ),
                  StockPill(stock: book.stock, variant: StockVariant.browse),
                ],
              ),
              const SizedBox(height: AppSpacing.md),
              Text(formatLKR(book.price), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.teal)),
              const SizedBox(height: AppSpacing.md),
              Text(book.description, style: const TextStyle(color: AppColors.textSecondary, fontSize: 14, height: 1.5)),
              if (!outOfStock)
                Padding(
                  padding: const EdgeInsets.only(top: AppSpacing.xl),
                  child: Row(
                    children: [
                      _StepButton(label: '−', onTap: () => setState(() => _quantity = _quantity > 1 ? _quantity - 1 : 1)),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
                        child: Text('$_quantity', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                      ),
                      _StepButton(label: '+', onTap: () => setState(() => _quantity = _quantity < book.stock ? _quantity + 1 : book.stock)),
                    ],
                  ),
                ),
              if (_error.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: AppSpacing.md),
                  child: Text(_error, style: const TextStyle(color: AppColors.danger)),
                ),
              if (_added)
                const Padding(
                  padding: EdgeInsets.only(top: AppSpacing.md),
                  child: Text('Added to cart.', style: TextStyle(color: AppColors.success, fontWeight: FontWeight.w600)),
                ),
              Padding(
                padding: const EdgeInsets.only(top: AppSpacing.lg),
                child: PrimaryButton(
                  title: outOfStock ? 'Out of stock' : 'Add to cart',
                  disabled: outOfStock,
                  loading: _adding,
                  onPressed: _onAdd,
                  width: double.infinity,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: AppSpacing.md),
                child: PrimaryButton(
                  title: 'View cart',
                  variant: ButtonVariant.outline,
                  width: double.infinity,
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CartScreen())),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StepButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _StepButton({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 40,
        height: 40,
        alignment: Alignment.center,
        decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: AppColors.teal, width: 1.5)),
        child: Text(label, style: const TextStyle(fontSize: 20, color: AppColors.teal, fontWeight: FontWeight.w700)),
      ),
    );
  }
}
