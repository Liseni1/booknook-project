import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../theme.dart';
import '../../widgets/primary_button.dart';
import '../../widgets/screen_header.dart';

const _roleLabel = {'customer': 'Customer', 'staff': 'Store Staff', 'admin': 'Administrator'};

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final user = auth.user!;
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          const ScreenHeader(title: 'Profile', icon: Icons.person_outline),
          Padding(
            padding: const EdgeInsets.all(AppSpacing.xl),
            child: Column(
              children: [
                Container(
                  width: 72,
                  height: 72,
                  alignment: Alignment.center,
                  decoration: const BoxDecoration(color: AppColors.teal, shape: BoxShape.circle),
                  child: const Icon(Icons.person, size: 32, color: AppColors.white),
                ),
                const SizedBox(height: AppSpacing.md),
                Text(user.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                const SizedBox(height: 4),
                Text(user.email, style: const TextStyle(color: AppColors.textSecondary)),
                Container(
                  margin: const EdgeInsets.only(top: AppSpacing.md),
                  padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: 6),
                  decoration: BoxDecoration(color: AppColors.peach, borderRadius: BorderRadius.circular(AppRadius.pill)),
                  child: Text(_roleLabel[user.role] ?? user.role, style: const TextStyle(color: AppColors.tealDark, fontWeight: FontWeight.w700, fontSize: 13)),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: PrimaryButton(
              title: 'Sign out',
              variant: ButtonVariant.outline,
              width: double.infinity,
              onPressed: () => auth.signOut(),
            ),
          ),
        ],
      ),
    );
  }
}
