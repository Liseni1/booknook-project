import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../api/api_client.dart';
import '../../models.dart';
import '../../providers/auth_provider.dart';
import '../../theme.dart';
import '../../widgets/screen_header.dart';

const _roles = ['customer', 'staff', 'admin'];
const _roleLabel = {'customer': 'Customer', 'staff': 'Store Staff', 'admin': 'Administrator'};

class UsersScreen extends StatefulWidget {
  const UsersScreen({super.key});

  @override
  State<UsersScreen> createState() => _UsersScreenState();
}

class _UsersScreenState extends State<UsersScreen> with AutomaticKeepAliveClientMixin {
  List<AppUser> _users = [];
  String _error = '';
  String? _busyId;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await apiClient.getUsers();
    setState(() {
      _users = ((data['users'] as List?) ?? []).map((e) => AppUser.fromJson(e as Map<String, dynamic>)).toList();
    });
  }

  Future<void> _setRole(String id, String role) async {
    setState(() {
      _busyId = id;
      _error = '';
    });
    try {
      await apiClient.updateUserRole(id, role);
      await _load();
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busyId = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final me = context.watch<AuthProvider>().user;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          const ScreenHeader(title: 'Users', icon: Icons.people_outline),
          if (_error.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.sm),
              child: Text(_error, style: const TextStyle(color: AppColors.danger)),
            ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(AppSpacing.lg),
              itemCount: _users.length,
              itemBuilder: (context, i) {
                final u = _users[i];
                return Container(
                  margin: const EdgeInsets.only(bottom: AppSpacing.md),
                  padding: const EdgeInsets.all(AppSpacing.md),
                  decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(AppRadius.lg)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${u.name}${u.id == me?.id ? ' (you)' : ''}',
                          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16, color: AppColors.textPrimary)),
                      Padding(
                        padding: const EdgeInsets.only(top: 2),
                        child: Text(u.email, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: AppSpacing.md),
                        child: Wrap(
                          spacing: AppSpacing.sm,
                          runSpacing: AppSpacing.sm,
                          children: _roles.map((r) {
                            final active = u.role == r;
                            return GestureDetector(
                              key: Key('role-chip-${u.email}-$r'),
                              onTap: _busyId == u.id ? null : () => _setRole(u.id, r),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: 6),
                                decoration: BoxDecoration(
                                  color: active ? AppColors.teal : AppColors.white,
                                  border: Border.all(color: active ? AppColors.teal : AppColors.border),
                                  borderRadius: BorderRadius.circular(AppRadius.pill),
                                ),
                                child: Text(_roleLabel[r]!,
                                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: active ? AppColors.white : AppColors.textPrimary)),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
