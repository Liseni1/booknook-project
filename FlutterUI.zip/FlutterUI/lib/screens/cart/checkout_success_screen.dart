import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models.dart';
import '../../providers/nav_provider.dart';
import '../../theme.dart';
import '../../widgets/primary_button.dart';

class CheckoutSuccessScreen extends StatelessWidget {
  final BookOrder order;
  const CheckoutSuccessScreen({super.key, required this.order});

  @override
  Widget build(BuildContext context) {
    final shortId = order.id.length >= 6 ? order.id.substring(order.id.length - 6).toUpperCase() : order.id.toUpperCase();
    return Scaffold(
      backgroundColor: AppColors.white,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(AppSpacing.xl),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.check_circle, size: 72, color: AppColors.success),
                const SizedBox(height: AppSpacing.lg),
                const Text('Order placed!', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                const SizedBox(height: AppSpacing.sm),
                Text('Order #$shortId — ${formatLKR(order.total)}', style: const TextStyle(fontSize: 15, color: AppColors.textSecondary)),
                PrimaryButton(
                  title: 'View my orders',
                  margin: const EdgeInsets.only(top: AppSpacing.xl),
                  width: double.infinity,
                  onPressed: () {
                    context.read<NavProvider>().select('orders');
                    Navigator.of(context).popUntil((r) => r.isFirst);
                  },
                ),
                PrimaryButton(
                  title: 'Continue shopping',
                  variant: ButtonVariant.outline,
                  margin: const EdgeInsets.only(top: AppSpacing.md),
                  width: double.infinity,
                  onPressed: () {
                    context.read<NavProvider>().select('browse');
                    Navigator.of(context).popUntil((r) => r.isFirst);
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
