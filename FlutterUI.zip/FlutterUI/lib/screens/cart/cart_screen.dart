import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../api/api_client.dart';
import '../../models.dart';
import '../../providers/cart_provider.dart';
import '../../theme.dart';
import '../../widgets/primary_button.dart';
import 'checkout_success_screen.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  String? _busyId;
  bool _checkingOut = false;
  String _error = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<CartProvider>().refresh());
  }

  Future<void> _updateQty(String bookId, int qty) async {
    setState(() {
      _busyId = bookId;
      _error = '';
    });
    try {
      if (qty <= 0) {
        await apiClient.removeCartItem(bookId);
      } else {
        await apiClient.updateCartItem(bookId, qty);
      }
      if (mounted) await context.read<CartProvider>().refresh();
    } on ApiException catch (e) {
      setState(() => _error = e.errors?['quantity'] ?? e.message);
    } finally {
      if (mounted) setState(() => _busyId = null);
    }
  }

  Future<void> _onCheckout() async {
    setState(() {
      _checkingOut = true;
      _error = '';
    });
    try {
      final data = await apiClient.checkout();
      if (!mounted) return;
      await context.read<CartProvider>().refresh();
      final order = BookOrder.fromJson(data['order'] as Map<String, dynamic>);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => CheckoutSuccessScreen(order: order)));
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _checkingOut = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.sm),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    key: const Key('back-button'),
                    onTap: () => Navigator.of(context).pop(),
                    child: const Icon(Icons.arrow_back, size: 24, color: AppColors.teal, semanticLabel: 'Back'),
                  ),
                  const Text('Your Cart', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                  const SizedBox(width: 24),
                ],
              ),
            ),
            Expanded(
              child: cart.items.isEmpty
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(AppSpacing.xl),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.shopping_cart_outlined, size: 48, color: AppColors.textSecondary),
                            const SizedBox(height: AppSpacing.md),
                            const Text('Your cart is empty.', style: TextStyle(color: AppColors.textSecondary, fontSize: 15)),
                            const SizedBox(height: AppSpacing.lg),
                            PrimaryButton(title: 'Browse books', onPressed: () => Navigator.of(context).pop()),
                          ],
                        ),
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(AppSpacing.lg),
                      itemCount: cart.items.length,
                      itemBuilder: (context, i) {
                        final item = cart.items[i];
                        return Container(
                          margin: const EdgeInsets.only(bottom: AppSpacing.md),
                          padding: const EdgeInsets.all(AppSpacing.md),
                          decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(AppRadius.lg)),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(item.title, maxLines: 2, overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.textPrimary, fontSize: 15)),
                                    const SizedBox(height: 2),
                                    Text(item.author, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                                    const SizedBox(height: 4),
                                    Text(formatLKR(item.price), style: const TextStyle(color: AppColors.teal, fontWeight: FontWeight.w700)),
                                  ],
                                ),
                              ),
                              _busyId == item.bookId
                                  ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.teal))
                                  : Row(
                                      children: [
                                        _StepBtn(label: '−', onTap: () => _updateQty(item.bookId, item.quantity - 1)),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md),
                                          child: Text('${item.quantity}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                                        ),
                                        _StepBtn(label: '+', onTap: () => _updateQty(item.bookId, item.quantity + 1)),
                                      ],
                                    ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
            if (_error.isNotEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
                child: Text(_error, style: const TextStyle(color: AppColors.danger)),
              ),
            if (cart.items.isNotEmpty)
              Container(
                padding: const EdgeInsets.all(AppSpacing.lg),
                decoration: const BoxDecoration(color: AppColors.white, border: Border(top: BorderSide(color: AppColors.border))),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Total', style: TextStyle(fontSize: 16, color: AppColors.textSecondary)),
                        Text(formatLKR(cart.total), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                      ],
                    ),
                    const SizedBox(height: AppSpacing.md),
                    PrimaryButton(title: 'Checkout', onPressed: _onCheckout, loading: _checkingOut, width: double.infinity),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _StepBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _StepBtn({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 30,
        height: 30,
        alignment: Alignment.center,
        decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: AppColors.teal, width: 1.5)),
        child: Text(label, style: const TextStyle(color: AppColors.teal, fontWeight: FontWeight.w700, fontSize: 16)),
      ),
    );
  }
}
