import 'package:flutter/material.dart';
import '../../api/api_client.dart';
import '../../theme.dart';
import '../../widgets/app_text_field.dart';
import '../../widgets/primary_button.dart';

class BookFormScreen extends StatefulWidget {
  final String? bookId;
  const BookFormScreen({super.key, this.bookId});

  @override
  State<BookFormScreen> createState() => _BookFormScreenState();
}

class _BookFormScreenState extends State<BookFormScreen> {
  bool get isEdit => widget.bookId != null;

  final _title = TextEditingController();
  final _author = TextEditingController();
  final _category = TextEditingController();
  final _isbn = TextEditingController();
  final _price = TextEditingController();
  final _stock = TextEditingController();
  final _description = TextEditingController();

  final Set<String> _touched = {};
  bool _submitting = false;
  bool _loaded = false;
  String _serverError = '';

  @override
  void initState() {
    super.initState();
    if (isEdit) {
      _load();
    } else {
      _loaded = true;
    }
  }

  Future<void> _load() async {
    final data = await apiClient.getBook(widget.bookId!);
    final b = data['book'] as Map<String, dynamic>;
    _title.text = b['title'] ?? '';
    _author.text = b['author'] ?? '';
    _category.text = b['category'] ?? '';
    _isbn.text = b['isbn']?.toString() ?? '';
    _price.text = '${b['price'] ?? ''}';
    _stock.text = '${b['stock'] ?? ''}';
    _description.text = b['description'] ?? '';
    setState(() => _loaded = true);
  }

  Map<String, String> get _errors {
    final errors = <String, String>{};
    if (_title.text.trim().isEmpty) errors['title'] = 'Title is required.';
    if (_author.text.trim().isEmpty) errors['author'] = 'Author is required.';
    if (_category.text.trim().isEmpty) errors['category'] = 'Category is required.';

    final isbnDigits = _isbn.text.replaceAll('-', '');
    if (!RegExp(r'^\d{10}$').hasMatch(isbnDigits) && !RegExp(r'^\d{13}$').hasMatch(isbnDigits)) {
      errors['isbn'] = 'Enter a valid 10 or 13 digit ISBN.';
    }

    final priceNum = num.tryParse(_price.text);
    if (_price.text.isEmpty || priceNum == null || priceNum <= 0) {
      errors['price'] = 'Price must be a number greater than 0.';
    }

    final stockNum = int.tryParse(_stock.text);
    if (_stock.text.isEmpty || stockNum == null || stockNum < 0) {
      errors['stock'] = 'Stock must be a whole number of 0 or more.';
    }

    return errors;
  }

  String? _show(String field) => (_touched.contains(field) || _touched.contains('submitted')) ? _errors[field] : null;

  Future<void> _onSubmit() async {
    setState(() {
      _touched.addAll(['title', 'author', 'category', 'isbn', 'price', 'stock', 'submitted']);
      _serverError = '';
    });
    if (_errors.isNotEmpty) return;

    setState(() => _submitting = true);
    final payload = {
      'title': _title.text.trim(),
      'author': _author.text.trim(),
      'category': _category.text.trim(),
      'isbn': _isbn.text.trim(),
      'price': num.parse(_price.text),
      'stock': int.parse(_stock.text),
      'description': _description.text,
    };
    try {
      if (isEdit) {
        await apiClient.updateBook(widget.bookId!, payload);
      } else {
        await apiClient.createBook(payload);
      }
      if (mounted) Navigator.of(context).pop();
    } on ApiException catch (e) {
      setState(() => _serverError = e.errors != null && e.errors!.isNotEmpty ? e.errors!.values.first : e.message);
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) {
      return const Scaffold(body: Center(child: CircularProgressIndicator(color: AppColors.teal)));
    }
    return Scaffold(
      backgroundColor: AppColors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(AppSpacing.lg),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                key: const Key('back-button'),
                onTap: () => Navigator.of(context).pop(),
                child: const Padding(
                  padding: EdgeInsets.only(bottom: AppSpacing.lg),
                  child: Icon(Icons.arrow_back, size: 24, color: AppColors.teal, semanticLabel: 'Back'),
                ),
              ),
              Text(isEdit ? 'Edit book' : 'Add a new book',
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
              const SizedBox(height: AppSpacing.lg),
              AppTextField(label: 'Title', controller: _title, error: _show('title'), onChanged: (_) => setState(() {})),
              AppTextField(label: 'Author', controller: _author, error: _show('author'), onChanged: (_) => setState(() {})),
              AppTextField(label: 'Category', controller: _category, error: _show('category'), onChanged: (_) => setState(() {})),
              AppTextField(label: 'ISBN', controller: _isbn, keyboardType: TextInputType.number, error: _show('isbn'), onChanged: (_) => setState(() {})),
              AppTextField(label: 'Price (LKR)', controller: _price, keyboardType: TextInputType.number, error: _show('price'), onChanged: (_) => setState(() {})),
              AppTextField(label: 'Stock', controller: _stock, keyboardType: TextInputType.number, error: _show('stock'), onChanged: (_) => setState(() {})),
              AppTextField(label: 'Description', controller: _description, maxLines: 4),
              if (_serverError.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: AppSpacing.sm),
                  child: Text(_serverError, style: const TextStyle(color: AppColors.danger)),
                ),
              Padding(
                padding: const EdgeInsets.only(top: AppSpacing.lg),
                child: PrimaryButton(
                  title: isEdit ? 'Save changes' : 'Add book',
                  onPressed: _onSubmit,
                  loading: _submitting,
                  width: double.infinity,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
