import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../api/api_client.dart';
import '../../models.dart';
import '../../providers/auth_provider.dart';
import '../../theme.dart';
import '../../widgets/app_search_bar.dart';
import '../../widgets/screen_header.dart';
import '../../widgets/stock_pill.dart';
import 'book_form_screen.dart';

class CatalogueScreen extends StatefulWidget {
  const CatalogueScreen({super.key});

  @override
  State<CatalogueScreen> createState() => _CatalogueScreenState();
}

class _CatalogueScreenState extends State<CatalogueScreen> with AutomaticKeepAliveClientMixin {
  final _search = TextEditingController();
  List<Book> _books = [];
  String? _deletingId;
  String _error = '';

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await apiClient.getBooks(search: _search.text.isEmpty ? null : _search.text);
    setState(() {
      _books = ((data['books'] as List?) ?? []).map((e) => Book.fromJson(e as Map<String, dynamic>)).toList();
    });
  }

  Future<void> _onDelete(String id) async {
    setState(() {
      _deletingId = id;
      _error = '';
    });
    try {
      await apiClient.deleteBook(id);
      await _load();
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _deletingId = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final isAdmin = context.watch<AuthProvider>().user?.role == 'admin';

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          ScreenHeader(
            title: 'Catalogue',
            icon: Icons.collections_bookmark_outlined,
            right: GestureDetector(
              key: const Key('add-book-button'),
              onTap: () async {
                await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BookFormScreen()));
                _load();
              },
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.2), borderRadius: BorderRadius.circular(20)),
                child: const Icon(Icons.add, size: 22, color: AppColors.white, semanticLabel: 'Add book'),
              ),
            ),
          ),
          Container(
            margin: const EdgeInsets.only(left: AppSpacing.lg, right: AppSpacing.lg, top: AppSpacing.md),
            padding: const EdgeInsets.all(AppSpacing.md),
            decoration: BoxDecoration(color: AppColors.infoBoxBg, borderRadius: BorderRadius.circular(AppRadius.md)),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.info_outline, size: 18, color: AppColors.tealDark),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: Text(
                    isAdmin
                        ? 'Signed in as Administrator: you can add, edit and delete catalogue entries.'
                        : 'Signed in as Store Staff: you can add and edit books. Deleting requires an Administrator.',
                    style: const TextStyle(color: AppColors.textSecondary, fontSize: 12, height: 1.4),
                  ),
                ),
              ],
            ),
          ),
          AppSearchBar(controller: _search, onChanged: (_) => _load()),
          if (_error.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.sm),
              child: Text(_error, style: const TextStyle(color: AppColors.danger)),
            ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(AppSpacing.lg),
              itemCount: _books.length,
              itemBuilder: (context, i) {
                final book = _books[i];
                return Container(
                  margin: const EdgeInsets.only(bottom: AppSpacing.md),
                  padding: const EdgeInsets.all(AppSpacing.md),
                  decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(AppRadius.lg)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Text(book.title, maxLines: 2, overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16, color: AppColors.textPrimary)),
                          ),
                          StockPill(stock: book.stock),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text('${book.author} · ${book.category}', style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: AppSpacing.md),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(formatLKR(book.price), style: const TextStyle(color: AppColors.teal, fontWeight: FontWeight.w800, fontSize: 15)),
                            Row(
                              children: [
                                GestureDetector(
                                  onTap: () async {
                                    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => BookFormScreen(bookId: book.id)));
                                    _load();
                                  },
                                  child: const Row(children: [
                                    Icon(Icons.edit_outlined, size: 16, color: AppColors.teal),
                                    SizedBox(width: 4),
                                    Text('Edit', style: TextStyle(color: AppColors.teal, fontWeight: FontWeight.w700)),
                                  ]),
                                ),
                                if (isAdmin)
                                  Padding(
                                    padding: const EdgeInsets.only(left: AppSpacing.lg),
                                    child: GestureDetector(
                                      onTap: _deletingId == book.id ? null : () => _onDelete(book.id),
                                      child: const Row(children: [
                                        Icon(Icons.delete_outline, size: 16, color: AppColors.danger),
                                        SizedBox(width: 4),
                                        Text('Delete', style: TextStyle(color: AppColors.danger, fontWeight: FontWeight.w700)),
                                      ]),
                                    ),
                                  ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
