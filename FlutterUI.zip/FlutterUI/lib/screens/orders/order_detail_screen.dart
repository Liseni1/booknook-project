import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../api/api_client.dart';
import '../../models.dart';
import '../../providers/auth_provider.dart';
import '../../theme.dart';

const Map<String, List<String>> _statusFlow = {
  'Pending': ['Processing', 'Cancelled'],
  'Processing': ['Shipped', 'Cancelled'],
  'Shipped': ['Delivered'],
  'Delivered': [],
  'Cancelled': [],
};

class OrderDetailScreen extends StatefulWidget {
  final String orderId;
  const OrderDetailScreen({super.key, required this.orderId});

  @override
  State<OrderDetailScreen> createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends State<OrderDetailScreen> {
  BookOrder? _order;
  bool _updating = false;
  String _error = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final data = await apiClient.getOrder(widget.orderId);
      setState(() => _order = BookOrder.fromJson(data['order'] as Map<String, dynamic>));
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    }
  }

  Future<void> _changeStatus(String status) async {
    setState(() {
      _updating = true;
      _error = '';
    });
    try {
      final data = await apiClient.updateOrderStatus(_order!.id, status);
      setState(() => _order = BookOrder.fromJson(data['order'] as Map<String, dynamic>));
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _updating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final order = _order;
    final role = context.watch<AuthProvider>().user?.role ?? 'customer';
    final canManage = role == 'staff' || role == 'admin';

    if (order == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator(color: AppColors.teal)));
    }

    final shortId = order.id.length >= 6 ? order.id.substring(order.id.length - 6).toUpperCase() : order.id.toUpperCase();
    final nextStatuses = _statusFlow[order.status] ?? [];

    return Scaffold(
      backgroundColor: AppColors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(AppSpacing.lg),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                key: const Key('back-button'),
                onTap: () => Navigator.of(context).pop(),
                child: const Padding(
                  padding: EdgeInsets.only(bottom: AppSpacing.lg),
                  child: Icon(Icons.arrow_back, size: 24, color: AppColors.teal, semanticLabel: 'Back'),
                ),
              ),
              Text('Order #$shortId', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(order.createdAt, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
              ),
              if (canManage)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text('Customer: ${order.customerName}', style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                ),
              Padding(
                padding: const EdgeInsets.only(top: AppSpacing.lg),
                child: Row(
                  children: [
                    const Text('Status', style: TextStyle(color: AppColors.textSecondary)),
                    const SizedBox(width: AppSpacing.sm),
                    Text(order.status, style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.teal, fontSize: 16)),
                  ],
                ),
              ),
              Container(
                margin: const EdgeInsets.only(top: AppSpacing.lg),
                padding: const EdgeInsets.all(AppSpacing.md),
                decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(AppRadius.lg)),
                child: Column(
                  children: [
                    ...order.items.map((it) => Padding(
                          padding: const EdgeInsets.only(bottom: AppSpacing.sm),
                          child: Row(
                            children: [
                              Expanded(child: Text(it.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w600))),
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm),
                                child: Text('x${it.quantity}', style: const TextStyle(color: AppColors.textSecondary)),
                              ),
                              Text(formatLKR(it.price * it.quantity), style: const TextStyle(color: AppColors.teal, fontWeight: FontWeight.w700)),
                            ],
                          ),
                        )),
                    Container(
                      padding: const EdgeInsets.only(top: AppSpacing.sm),
                      decoration: const BoxDecoration(border: Border(top: BorderSide(color: AppColors.border))),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Total', style: TextStyle(color: AppColors.textSecondary)),
                          Text(formatLKR(order.total), style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              if (_error.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: AppSpacing.md),
                  child: Text(_error, style: const TextStyle(color: AppColors.danger)),
                ),
              if (canManage && nextStatuses.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: AppSpacing.xl),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Update status', style: TextStyle(color: AppColors.textSecondary)),
                      const SizedBox(height: AppSpacing.sm),
                      Wrap(
                        spacing: AppSpacing.sm,
                        runSpacing: AppSpacing.sm,
                        children: nextStatuses
                            .map((s) => GestureDetector(
                                  key: Key('status-$s'),
                                  onTap: _updating ? null : () => _changeStatus(s),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.sm),
                                    decoration: BoxDecoration(
                                      border: Border.all(color: AppColors.teal, width: 1.5),
                                      borderRadius: BorderRadius.circular(AppRadius.pill),
                                    ),
                                    child: Text(s, style: const TextStyle(color: AppColors.teal, fontWeight: FontWeight.w700)),
                                  ),
                                ))
                            .toList(),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
