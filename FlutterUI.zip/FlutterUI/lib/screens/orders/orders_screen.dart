import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../api/api_client.dart';
import '../../models.dart';
import '../../providers/auth_provider.dart';
import '../../theme.dart';
import '../../widgets/screen_header.dart';
import 'order_detail_screen.dart';

const Map<String, Color> _statusFg = {
  'Pending': AppColors.warning,
  'Processing': AppColors.info,
  'Shipped': AppColors.purple,
  'Delivered': AppColors.success,
  'Cancelled': AppColors.danger,
};
const Map<String, Color> _statusBg = {
  'Pending': AppColors.warningBg,
  'Processing': AppColors.infoBg,
  'Shipped': AppColors.purpleBg,
  'Delivered': AppColors.successBg,
  'Cancelled': AppColors.dangerBg,
};

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> with AutomaticKeepAliveClientMixin {
  List<BookOrder> _orders = [];
  bool _loading = true;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final data = await apiClient.getOrders();
      setState(() {
        _orders = ((data['orders'] as List?) ?? []).map((e) => BookOrder.fromJson(e as Map<String, dynamic>)).toList();
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final role = context.watch<AuthProvider>().user?.role ?? 'customer';
    final isStaffOrAdmin = role == 'staff' || role == 'admin';

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          const ScreenHeader(title: 'Orders', icon: Icons.inventory_2_outlined),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: AppColors.teal))
                : RefreshIndicator(
                    onRefresh: _load,
                    color: AppColors.teal,
                    child: _orders.isEmpty
                        ? ListView(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(top: AppSpacing.xl),
                                child: Center(
                                  child: Text(
                                    isStaffOrAdmin ? 'No orders yet.' : "You haven't placed any orders yet.",
                                    style: const TextStyle(color: AppColors.textSecondary),
                                  ),
                                ),
                              ),
                            ],
                          )
                        : ListView.builder(
                            padding: const EdgeInsets.all(AppSpacing.lg),
                            itemCount: _orders.length,
                            itemBuilder: (context, i) {
                              final order = _orders[i];
                              final shortId = order.id.length >= 6 ? order.id.substring(order.id.length - 6).toUpperCase() : order.id.toUpperCase();
                              final fg = _statusFg[order.status] ?? AppColors.warning;
                              final bg = _statusBg[order.status] ?? AppColors.warningBg;
                              return GestureDetector(
                                onTap: () async {
                                  await Navigator.of(context).push(MaterialPageRoute(builder: (_) => OrderDetailScreen(orderId: order.id)));
                                  _load();
                                },
                                child: Container(
                                  margin: const EdgeInsets.only(bottom: AppSpacing.md),
                                  padding: const EdgeInsets.all(AppSpacing.md),
                                  decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(AppRadius.lg)),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text('Order #$shortId', style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.textPrimary, fontSize: 15)),
                                            if (isStaffOrAdmin)
                                              Padding(
                                                padding: const EdgeInsets.only(top: 2),
                                                child: Text(order.customerName, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                                              ),
                                            Padding(
                                              padding: const EdgeInsets.only(top: 2),
                                              child: Text(order.createdAt, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(top: 6),
                                              child: Text(formatLKR(order.total), style: const TextStyle(color: AppColors.teal, fontWeight: FontWeight.w800)),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(AppRadius.pill)),
                                        child: Text(order.status, style: TextStyle(color: fg, fontSize: 12, fontWeight: FontWeight.w700)),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
          ),
        ],
      ),
    );
  }
}
