import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/auth_provider.dart';
import 'providers/nav_provider.dart';
import 'screens/browse/browse_screen.dart';
import 'screens/catalogue/catalogue_screen.dart';
import 'screens/orders/orders_screen.dart';
import 'screens/profile/profile_screen.dart';
import 'screens/users/users_screen.dart';
import 'theme.dart';

class _TabDef {
  final String key;
  final String label;
  final IconData icon;
  final Widget Function() build;
  const _TabDef(this.key, this.label, this.icon, this.build);
}

class MainShell extends StatelessWidget {
  const MainShell({super.key});

  List<_TabDef> _tabsForRole(String role) {
    final tabs = <_TabDef>[
      _TabDef('browse', 'Browse', Icons.menu_book_outlined, () => const BrowseScreen()),
    ];
    if (role == 'staff' || role == 'admin') {
      tabs.add(_TabDef('catalogue', 'Catalogue', Icons.collections_bookmark_outlined, () => const CatalogueScreen()));
    }
    tabs.add(_TabDef('orders', 'Orders', Icons.inventory_2_outlined, () => const OrdersScreen()));
    if (role == 'admin') {
      tabs.add(_TabDef('users', 'Users', Icons.people_outline, () => const UsersScreen()));
    }
    tabs.add(_TabDef('profile', 'Profile', Icons.person_outline, () => const ProfileScreen()));
    return tabs;
  }

  @override
  Widget build(BuildContext context) {
    final role = context.watch<AuthProvider>().user?.role ?? 'customer';
    final nav = context.watch<NavProvider>();
    final tabs = _tabsForRole(role);

    var index = tabs.indexWhere((t) => t.key == nav.selected);
    if (index < 0) index = 0;

    return Scaffold(
      // Deliberately NOT an IndexedStack: each screen loads its own data in
      // initState (books, orders, catalogue, users) with no separate
      // "on tab focus" refresh hook, so keeping every tab's widget alive
      // forever (IndexedStack's usual purpose) meant e.g. Orders kept
      // showing its stale first-load snapshot even after a new order was
      // placed. Rebuilding the selected tab fresh on every switch trades
      // away preserved scroll position for always-correct data, which
      // matters more here. Keyed so Flutter treats each tab switch as a
      // genuinely new widget instance rather than reusing state.
      body: KeyedSubtree(
        key: ValueKey(tabs[index].key),
        child: tabs[index].build(),
      ),
      bottomNavigationBar: Container(
        height: 66,
        padding: const EdgeInsets.only(top: 8, bottom: 10),
        decoration: const BoxDecoration(color: Color(0xFFEAF2F1)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: tabs.asMap().entries.map((entry) {
            final i = entry.key;
            final t = entry.value;
            final active = i == index;
            return GestureDetector(
              key: Key('tab-${t.key}'),
              onTap: () => context.read<NavProvider>().select(t.key),
              behavior: HitTestBehavior.opaque,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: active ? 16 : 16, vertical: 4),
                    decoration: BoxDecoration(
                      color: active ? AppColors.peach : Colors.transparent,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Icon(t.icon, size: 20, color: active ? AppColors.tealDark : const Color(0xFF8A9491)),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    t.label,
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: active ? AppColors.tealDark : const Color(0xFF8A9491),
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}
