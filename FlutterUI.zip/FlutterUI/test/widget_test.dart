// Basic smoke test: the app boots to the Sign In screen when signed out.

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:booknook/main.dart';

void main() {
  testWidgets('App boots to sign-in screen', (WidgetTester tester) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(const BookNookApp());
    await tester.pumpAndSettle();

    expect(find.text('Welcome back'), findsOneWidget);
    expect(find.text('BookNook'), findsOneWidget);
  });
}
