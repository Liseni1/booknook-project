const request = require('supertest');
const { createApp } = require('../src/app');
const { createDb } = require('../src/db');
const { loginAs } = require('./helpers');

describe('Users (admin)', () => {
  let app;
  let adminToken;
  let staffToken;

  beforeEach(async () => {
    app = createApp(createDb({}));
    adminToken = await loginAs(app, 'admin@booknook.lk');
    staffToken = await loginAs(app, 'staff@booknook.lk');
  });

  test('non-admin cannot list users', async () => {
    const res = await request(app).get('/api/users').set('Authorization', `Bearer ${staffToken}`);
    expect(res.status).toBe(403);
  });

  test('admin can list users without exposing password hashes', async () => {
    const res = await request(app).get('/api/users').set('Authorization', `Bearer ${adminToken}`);
    expect(res.status).toBe(200);
    expect(res.body.users.length).toBe(3);
    expect(res.body.users[0].passwordHash).toBeUndefined();
  });

  test('admin can promote a customer to staff', async () => {
    const users = (await request(app).get('/api/users').set('Authorization', `Bearer ${adminToken}`)).body.users;
    const customer = users.find((u) => u.role === 'customer');
    const res = await request(app)
      .patch(`/api/users/${customer.id}/role`)
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ role: 'staff' });
    expect(res.status).toBe(200);
    expect(res.body.user.role).toBe('staff');
  });

  test('cannot demote the sole remaining administrator', async () => {
    const users = (await request(app).get('/api/users').set('Authorization', `Bearer ${adminToken}`)).body.users;
    const admin = users.find((u) => u.role === 'admin');
    const res = await request(app)
      .patch(`/api/users/${admin.id}/role`)
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ role: 'staff' });
    expect(res.status).toBe(400);
  });
});
