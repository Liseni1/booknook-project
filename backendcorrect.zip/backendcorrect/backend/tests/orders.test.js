const request = require('supertest');
const { createApp } = require('../src/app');
const { createDb } = require('../src/db');
const { loginAs } = require('./helpers');

describe('Orders', () => {
  let app;
  let custToken;
  let staffToken;
  let bookId;

  beforeEach(async () => {
    app = createApp(createDb({}));
    custToken = await loginAs(app, 'customer@booknook.lk');
    staffToken = await loginAs(app, 'staff@booknook.lk');
    const books = (await request(app).get('/api/books')).body.books;
    bookId = books.find((b) => b.title === 'Atomic Habits').id;
  });

  test('checkout fails with an empty cart', async () => {
    const res = await request(app).post('/api/orders').set('Authorization', `Bearer ${custToken}`).send({});
    expect(res.status).toBe(400);
  });

  test('checkout decrements stock, creates an order and clears the cart', async () => {
    await request(app).post('/api/cart/items').set('Authorization', `Bearer ${custToken}`).send({ bookId, quantity: 3 });
    const before = (await request(app).get(`/api/books/${bookId}`)).body.book.stock;

    const orderRes = await request(app).post('/api/orders').set('Authorization', `Bearer ${custToken}`).send({});
    expect(orderRes.status).toBe(201);
    expect(orderRes.body.order.status).toBe('Pending');

    const after = (await request(app).get(`/api/books/${bookId}`)).body.book.stock;
    expect(after).toBe(before - 3);

    const cart = await request(app).get('/api/cart').set('Authorization', `Bearer ${custToken}`);
    expect(cart.body.items.length).toBe(0);
  });

  test('a customer cannot change order status', async () => {
    await request(app).post('/api/cart/items').set('Authorization', `Bearer ${custToken}`).send({ bookId, quantity: 1 });
    const order = (await request(app).post('/api/orders').set('Authorization', `Bearer ${custToken}`).send({})).body.order;
    const res = await request(app)
      .patch(`/api/orders/${order.id}/status`)
      .set('Authorization', `Bearer ${custToken}`)
      .send({ status: 'Shipped' });
    expect(res.status).toBe(403);
  });

  test('staff can update status but not to an invalid value or after Delivered', async () => {
    await request(app).post('/api/cart/items').set('Authorization', `Bearer ${custToken}`).send({ bookId, quantity: 1 });
    const order = (await request(app).post('/api/orders').set('Authorization', `Bearer ${custToken}`).send({})).body.order;

    const bad = await request(app)
      .patch(`/api/orders/${order.id}/status`)
      .set('Authorization', `Bearer ${staffToken}`)
      .send({ status: 'Bogus' });
    expect(bad.status).toBe(400);

    const ok = await request(app)
      .patch(`/api/orders/${order.id}/status`)
      .set('Authorization', `Bearer ${staffToken}`)
      .send({ status: 'Delivered' });
    expect(ok.status).toBe(200);

    const after = await request(app)
      .patch(`/api/orders/${order.id}/status`)
      .set('Authorization', `Bearer ${staffToken}`)
      .send({ status: 'Processing' });
    expect(after.status).toBe(400);
  });
});
