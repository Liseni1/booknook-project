const request = require('supertest');
const { createApp } = require('../src/app');
const { createDb } = require('../src/db');
const { loginAs } = require('./helpers');

describe('Cart', () => {
  let app;
  let token;
  let bookId;
  let outOfStockId;

  beforeEach(async () => {
    app = createApp(createDb({}));
    token = await loginAs(app, 'customer@booknook.lk');
    const books = (await request(app).get('/api/books')).body.books;
    bookId = books.find((b) => b.title === 'Atomic Habits').id;
    outOfStockId = books.find((b) => b.title === 'To Kill a Mockingbird').id;
  });

  test('requires authentication', async () => {
    const res = await request(app).get('/api/cart');
    expect(res.status).toBe(401);
  });

  test('adding an out-of-stock book is rejected', async () => {
    const res = await request(app)
      .post('/api/cart/items')
      .set('Authorization', `Bearer ${token}`)
      .send({ bookId: outOfStockId, quantity: 1 });
    expect(res.status).toBe(400);
  });

  test('can add an in-stock book to the cart', async () => {
    const res = await request(app)
      .post('/api/cart/items')
      .set('Authorization', `Bearer ${token}`)
      .send({ bookId, quantity: 2 });
    expect(res.status).toBe(201);
    expect(res.body.items[0].quantity).toBe(2);
  });

  test('rejects a quantity greater than available stock', async () => {
    const res = await request(app)
      .post('/api/cart/items')
      .set('Authorization', `Bearer ${token}`)
      .send({ bookId, quantity: 9999 });
    expect(res.status).toBe(400);
  });

  test('can update and remove a cart line', async () => {
    await request(app).post('/api/cart/items').set('Authorization', `Bearer ${token}`).send({ bookId, quantity: 1 });
    const updateRes = await request(app)
      .put(`/api/cart/items/${bookId}`)
      .set('Authorization', `Bearer ${token}`)
      .send({ quantity: 3 });
    expect(updateRes.status).toBe(200);
    expect(updateRes.body.items[0].quantity).toBe(3);

    const removeRes = await request(app).delete(`/api/cart/items/${bookId}`).set('Authorization', `Bearer ${token}`);
    expect(removeRes.status).toBe(200);
    expect(removeRes.body.items.length).toBe(0);
  });
});
