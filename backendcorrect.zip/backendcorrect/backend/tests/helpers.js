const request = require('supertest');

async function loginAs(app, email) {
  const res = await request(app).post('/api/auth/login').send({ email, password: 'Passw0rd!' });
  return res.body.token;
}

module.exports = { loginAs };
