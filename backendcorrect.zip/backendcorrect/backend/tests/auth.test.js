const request = require('supertest');
const { createApp } = require('../src/app');
const { createDb } = require('../src/db');

describe('Auth', () => {
  let app;
  beforeEach(() => {
    app = createApp(createDb({}));
  });

  test('register requires name, email, password', async () => {
    const res = await request(app).post('/api/auth/register').send({});
    expect(res.status).toBe(400);
    expect(res.body.errors.name).toBeDefined();
    expect(res.body.errors.email).toBeDefined();
    expect(res.body.errors.password).toBeDefined();
  });

  test('register rejects invalid email and weak password', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({ name: 'Test User', email: 'not-an-email', password: '123' });
    expect(res.status).toBe(400);
    expect(res.body.errors.email).toMatch(/valid/i);
    expect(res.body.errors.password).toMatch(/8 characters/i);
  });

  test('register succeeds with valid data and always assigns the customer role', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({ name: 'Jane Doe', email: 'jane@example.com', password: 'Password1', role: 'admin' });
    expect(res.status).toBe(201);
    expect(res.body.user.role).toBe('customer');
    expect(res.body.token).toBeDefined();
  });

  test('register rejects a duplicate email', async () => {
    await request(app).post('/api/auth/register').send({ name: 'Jane Doe', email: 'jane@example.com', password: 'Password1' });
    const res = await request(app)
      .post('/api/auth/register')
      .send({ name: 'Jane Two', email: 'jane@example.com', password: 'Password1' });
    expect(res.status).toBe(400);
    expect(res.body.errors.email).toMatch(/already registered/i);
  });

  test('login succeeds with a seeded admin account', async () => {
    const res = await request(app).post('/api/auth/login').send({ email: 'admin@booknook.lk', password: 'Passw0rd!' });
    expect(res.status).toBe(200);
    expect(res.body.user.role).toBe('admin');
    expect(res.body.token).toBeDefined();
  });

  test('login fails with the wrong password', async () => {
    const res = await request(app).post('/api/auth/login').send({ email: 'admin@booknook.lk', password: 'wrong-password' });
    expect(res.status).toBe(401);
  });
});
