const request = require('supertest');
const { createApp } = require('../src/app');
const { createDb } = require('../src/db');
const { loginAs } = require('./helpers');

describe('Books', () => {
  let app;
  beforeEach(() => {
    app = createApp(createDb({}));
  });

  test('anyone can list all seeded books', async () => {
    const res = await request(app).get('/api/books');
    expect(res.status).toBe(200);
    expect(res.body.books.length).toBe(12);
  });

  test('search filters by title/author', async () => {
    const res = await request(app).get('/api/books?search=clean');
    expect(res.status).toBe(200);
    expect(res.body.books.some((b) => b.title === 'Clean Code')).toBe(true);
  });

  test('category filter narrows results', async () => {
    const res = await request(app).get('/api/books?category=Fiction');
    expect(res.status).toBe(200);
    expect(res.body.books.every((b) => b.category === 'Fiction')).toBe(true);
  });

  test('customer cannot create a book', async () => {
    const token = await loginAs(app, 'customer@booknook.lk');
    const res = await request(app)
      .post('/api/books')
      .set('Authorization', `Bearer ${token}`)
      .send({ title: 'X', author: 'Y', category: 'Fiction', isbn: '1234567890', price: 100, stock: 1 });
    expect(res.status).toBe(403);
  });

  test('staff can create a book', async () => {
    const token = await loginAs(app, 'staff@booknook.lk');
    const res = await request(app)
      .post('/api/books')
      .set('Authorization', `Bearer ${token}`)
      .send({ title: 'New Book', author: 'Some Author', category: 'Fiction', isbn: '1234567890', price: 1500, stock: 5 });
    expect(res.status).toBe(201);
    expect(res.body.book.title).toBe('New Book');
  });

  test('rejects invalid price and stock on create', async () => {
    const token = await loginAs(app, 'admin@booknook.lk');
    const res = await request(app)
      .post('/api/books')
      .set('Authorization', `Bearer ${token}`)
      .send({ title: 'X', author: 'Y', category: 'Fiction', isbn: '1234567890', price: -5, stock: -1 });
    expect(res.status).toBe(400);
    expect(res.body.errors.price).toBeDefined();
    expect(res.body.errors.stock).toBeDefined();
  });

  test('staff cannot delete a book but admin can', async () => {
    const staffToken = await loginAs(app, 'staff@booknook.lk');
    const listRes = await request(app).get('/api/books');
    const bookId = listRes.body.books[0].id;

    const staffDelete = await request(app).delete(`/api/books/${bookId}`).set('Authorization', `Bearer ${staffToken}`);
    expect(staffDelete.status).toBe(403);

    const adminToken = await loginAs(app, 'admin@booknook.lk');
    const adminDelete = await request(app).delete(`/api/books/${bookId}`).set('Authorization', `Bearer ${adminToken}`);
    expect(adminDelete.status).toBe(204);
  });
});
