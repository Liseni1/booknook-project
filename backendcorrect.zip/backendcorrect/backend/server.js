const path = require('path');
const { createApp } = require('./src/app');
const { createDb } = require('./src/db');

const PORT = process.env.PORT || 4000;
const db = createDb({ file: path.join(__dirname, 'data', 'db.json') });
const app = createApp(db);

app.listen(PORT, () => {
  console.log(`BookNook API listening on http://localhost:${PORT}`);
});
