const fs = require('fs');
const path = require('path');
const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync');
const Memory = require('lowdb/adapters/Memory');
const bcrypt = require('bcryptjs');

const SEED_BOOKS = [
  {
    title: 'Android Programming: The Big Nerd Ranch Guide',
    author: 'Bill Phillips & Chris Stewart',
    isbn: '9780135224340',
    category: 'Programming',
    price: 7300,
    stock: 1,
    description: 'A hands-on guide to building Android apps, covering activities, fragments, navigation and modern Android tooling through guided projects.',
  },
  {
    title: 'Atomic Habits',
    author: 'James Clear',
    isbn: '9780735211292',
    category: 'Self Help',
    price: 3200,
    stock: 25,
    description: 'A practical framework for building good habits and breaking bad ones, based on small, consistent, one-percent improvements.',
  },
  {
    title: 'Clean Code',
    author: 'Robert C. Martin',
    isbn: '9780132350884',
    category: 'Programming',
    price: 4850,
    stock: 12,
    description: 'A handbook of agile software craftsmanship that teaches principles, patterns and practices for writing readable, maintainable code.',
  },
  {
    title: 'Educated: A Memoir',
    author: 'Tara Westover',
    isbn: '9780399590504',
    category: 'Biography',
    price: 3600,
    stock: 9,
    description: 'A memoir about a woman who leaves her survivalist family and pursues an education that transforms her life.',
  },
  {
    title: 'The Pragmatic Programmer',
    author: 'David Thomas & Andrew Hunt',
    isbn: '9780135957059',
    category: 'Programming',
    price: 5200,
    stock: 6,
    description: 'Timeless tips and tricks for becoming a more effective and pragmatic software developer.',
  },
  {
    title: 'Deep Work',
    author: 'Cal Newport',
    isbn: '9781455586691',
    category: 'Self Help',
    price: 2900,
    stock: 14,
    description: 'Rules for focused success in a distracted world, arguing that the ability to concentrate deeply is a valuable and increasingly rare skill.',
  },
  {
    title: 'Steve Jobs',
    author: 'Walter Isaacson',
    isbn: '9781451648539',
    category: 'Biography',
    price: 4400,
    stock: 5,
    description: 'The definitive biography of Apple co-founder Steve Jobs, based on extensive interviews with Jobs and those around him.',
  },
  {
    title: '1984',
    author: 'George Orwell',
    isbn: '9780451524935',
    category: 'Fiction',
    price: 1800,
    stock: 30,
    description: 'A dystopian novel exploring surveillance, propaganda and totalitarian control in the imagined superstate of Oceania.',
  },
  {
    title: 'To Kill a Mockingbird',
    author: 'Harper Lee',
    isbn: '9780061120084',
    category: 'Fiction',
    price: 2100,
    stock: 0,
    description: 'A classic novel of racial injustice and moral growth seen through the eyes of a young girl in the American South.',
  },
  {
    title: 'Rich Dad Poor Dad',
    author: 'Robert Kiyosaki',
    isbn: '9781612680194',
    category: 'Finance',
    price: 2500,
    stock: 18,
    description: 'A personal finance classic contrasting two approaches to money, work and investing through the author\'s two father figures.',
  },
  {
    title: 'The Psychology of Money',
    author: 'Morgan Housel',
    isbn: '9780857197689',
    category: 'Finance',
    price: 2750,
    stock: 20,
    description: 'Short stories exploring the strange ways people think about money and teaching readers how to make better financial decisions.',
  },
  {
    title: 'The Lean Startup',
    author: 'Eric Ries',
    isbn: '9780307887894',
    category: 'Finance',
    price: 3100,
    stock: 8,
    description: 'A methodology for developing businesses and products through validated learning, rapid experimentation and iterative releases.',
  },
];

function seedUsers() {
  return [
    {
      id: 'u-admin',
      name: 'Ashen Perera',
      email: 'admin@booknook.lk',
      passwordHash: bcrypt.hashSync('Passw0rd!', 8),
      role: 'admin',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'u-staff',
      name: 'Nadeesha Silva',
      email: 'staff@booknook.lk',
      passwordHash: bcrypt.hashSync('Passw0rd!', 8),
      role: 'staff',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'u-customer',
      name: 'Kasun Fernando',
      email: 'customer@booknook.lk',
      passwordHash: bcrypt.hashSync('Passw0rd!', 8),
      role: 'customer',
      createdAt: new Date().toISOString(),
    },
  ];
}

function seedBooks() {
  return SEED_BOOKS.map((b, i) => ({
    id: `b-seed-${i + 1}`,
    coverLetter: b.title.trim().charAt(0).toUpperCase(),
    ...b,
  }));
}

function createDb({ file } = {}) {
  let adapter;
  if (file) {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    adapter = new FileSync(file);
  } else {
    adapter = new Memory();
  }
  const db = low(adapter);
  db.defaults({
    users: seedUsers(),
    books: seedBooks(),
    carts: {},
    orders: [],
  }).write();
  return db;
}

module.exports = { createDb };
