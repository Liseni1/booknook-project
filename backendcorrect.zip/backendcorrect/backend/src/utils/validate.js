function isValidEmail(email) {
  return typeof email === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

function isValidPassword(password) {
  return typeof password === 'string' && password.length >= 8 && /\d/.test(password);
}

function isValidIsbn(isbn) {
  const digits = String(isbn || '').replace(/-/g, '');
  return /^\d{10}$/.test(digits) || /^\d{13}$/.test(digits);
}

module.exports = { isValidEmail, isValidPassword, isValidIsbn };
