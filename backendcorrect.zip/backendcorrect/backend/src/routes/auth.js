const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { isValidEmail, isValidPassword } = require('../utils/validate');
const { genId, publicUser } = require('../utils/helpers');
const { SECRET } = require('../middleware/auth');

module.exports = function authRoutes(db) {
  const router = express.Router();

  router.post('/register', (req, res) => {
    const { name, email, password } = req.body || {};
    const errors = {};

    if (!name || !String(name).trim()) {
      errors.name = 'Full name is required.';
    } else if (String(name).trim().length > 60) {
      errors.name = 'Full name must be 60 characters or fewer.';
    }

    if (!email || !String(email).trim()) {
      errors.email = 'Email address is required.';
    } else if (!isValidEmail(email)) {
      errors.email = 'Enter a valid email address.';
    } else if (db.get('users').find({ email: String(email).trim().toLowerCase() }).value()) {
      errors.email = 'This email is already registered.';
    }

    if (!password) {
      errors.password = 'Password is required.';
    } else if (!isValidPassword(password)) {
      errors.password = 'Password must be at least 8 characters and include a number.';
    }

    if (Object.keys(errors).length) {
      return res.status(400).json({ errors });
    }

    const user = {
      id: genId('u'),
      name: String(name).trim(),
      email: String(email).trim().toLowerCase(),
      passwordHash: bcrypt.hashSync(password, 8),
      role: 'customer',
      createdAt: new Date().toISOString(),
    };
    db.get('users').push(user).write();
    db.set(`carts.${user.id}`, []).write();

    const token = jwt.sign({ id: user.id, role: user.role, name: user.name }, SECRET, { expiresIn: '7d' });
    res.status(201).json({ token, user: publicUser(user) });
  });

  router.post('/login', (req, res) => {
    const { email, password } = req.body || {};
    const errors = {};
    if (!email || !String(email).trim()) errors.email = 'Email address is required.';
    if (!password) errors.password = 'Password is required.';
    if (Object.keys(errors).length) {
      return res.status(400).json({ errors });
    }

    const user = db.get('users').find({ email: String(email).trim().toLowerCase() }).value();
    if (!user || !bcrypt.compareSync(password, user.passwordHash)) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const token = jwt.sign({ id: user.id, role: user.role, name: user.name }, SECRET, { expiresIn: '7d' });
    res.json({ token, user: publicUser(user) });
  });

  return router;
};
