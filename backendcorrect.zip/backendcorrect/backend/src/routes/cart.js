const express = require('express');
const { authenticate } = require('../middleware/auth');

module.exports = function cartRoutes(db) {
  const router = express.Router();
  router.use(authenticate);

  function getItems(userId) {
    return db.get(`carts.${userId}`).value() || [];
  }

  function ensureCart(userId) {
    if (!db.get(`carts.${userId}`).value()) {
      db.set(`carts.${userId}`, []).write();
    }
  }

  function hydrate(items) {
    return items
      .map((it) => {
        const book = db.get('books').find({ id: it.bookId }).value();
        if (!book) return null;
        return {
          bookId: book.id,
          title: book.title,
          author: book.author,
          price: book.price,
          stock: book.stock,
          quantity: it.quantity,
          lineTotal: book.price * it.quantity,
        };
      })
      .filter(Boolean);
  }

  router.get('/', (req, res) => {
    const items = hydrate(getItems(req.user.id));
    const total = items.reduce((sum, it) => sum + it.lineTotal, 0);
    res.json({ items, total });
  });

  router.post('/items', (req, res) => {
    const { bookId } = req.body || {};
    const quantity = Number(req.body && req.body.quantity);

    if (!bookId) return res.status(400).json({ errors: { bookId: 'Book is required.' } });
    if (!Number.isInteger(quantity) || quantity < 1) {
      return res.status(400).json({ errors: { quantity: 'Quantity must be at least 1.' } });
    }
    const book = db.get('books').find({ id: bookId }).value();
    if (!book) return res.status(404).json({ error: 'Book not found.' });

    ensureCart(req.user.id);
    const items = getItems(req.user.id);
    const existing = items.find((it) => it.bookId === bookId);
    const newQuantity = (existing ? existing.quantity : 0) + quantity;

    if (newQuantity > book.stock) {
      return res.status(400).json({ errors: { quantity: `Only ${book.stock} left in stock.` } });
    }
    if (existing) existing.quantity = newQuantity;
    else items.push({ bookId, quantity });

    db.set(`carts.${req.user.id}`, items).write();
    res.status(201).json({ items: hydrate(items) });
  });

  router.put('/items/:bookId', (req, res) => {
    const quantity = Number(req.body && req.body.quantity);
    if (!Number.isInteger(quantity) || quantity < 1) {
      return res.status(400).json({ errors: { quantity: 'Quantity must be at least 1.' } });
    }
    const book = db.get('books').find({ id: req.params.bookId }).value();
    if (!book) return res.status(404).json({ error: 'Book not found.' });
    if (quantity > book.stock) {
      return res.status(400).json({ errors: { quantity: `Only ${book.stock} left in stock.` } });
    }

    const items = getItems(req.user.id);
    const existing = items.find((it) => it.bookId === req.params.bookId);
    if (!existing) return res.status(404).json({ error: 'Item not in cart.' });
    existing.quantity = quantity;

    db.set(`carts.${req.user.id}`, items).write();
    res.json({ items: hydrate(items) });
  });

  router.delete('/items/:bookId', (req, res) => {
    const items = getItems(req.user.id).filter((it) => it.bookId !== req.params.bookId);
    db.set(`carts.${req.user.id}`, items).write();
    res.json({ items: hydrate(items) });
  });

  router.delete('/', (req, res) => {
    db.set(`carts.${req.user.id}`, []).write();
    res.status(204).end();
  });

  return router;
};
