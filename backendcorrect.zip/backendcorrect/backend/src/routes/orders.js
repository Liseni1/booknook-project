const express = require('express');
const { authenticate, requireRole } = require('../middleware/auth');
const { genId } = require('../utils/helpers');

const VALID_STATUSES = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];
const TERMINAL_STATUSES = ['Delivered', 'Cancelled'];

module.exports = function ordersRoutes(db) {
  const router = express.Router();
  router.use(authenticate);

  router.post('/', (req, res) => {
    const items = db.get(`carts.${req.user.id}`).value() || [];
    if (!items.length) return res.status(400).json({ error: 'Your cart is empty.' });

    const lineItems = [];
    for (const it of items) {
      const book = db.get('books').find({ id: it.bookId }).value();
      if (!book) return res.status(400).json({ error: 'A book in your cart is no longer available.' });
      if (it.quantity > book.stock) {
        return res.status(400).json({ error: `${book.title} only has ${book.stock} left in stock.` });
      }
      lineItems.push({ bookId: book.id, title: book.title, price: book.price, quantity: it.quantity });
    }

    lineItems.forEach((li) => {
      const ref = db.get('books').find({ id: li.bookId });
      ref.assign({ stock: ref.value().stock - li.quantity }).write();
    });

    const total = lineItems.reduce((sum, li) => sum + li.price * li.quantity, 0);
    const order = {
      id: genId('ord'),
      userId: req.user.id,
      customerName: req.user.name,
      items: lineItems,
      total,
      status: 'Pending',
      createdAt: new Date().toISOString(),
    };
    db.get('orders').push(order).write();
    db.set(`carts.${req.user.id}`, []).write();
    res.status(201).json({ order });
  });

  router.get('/', (req, res) => {
    let orders = db.get('orders').value();
    if (!['staff', 'admin'].includes(req.user.role)) {
      orders = orders.filter((o) => o.userId === req.user.id);
    }
    if (req.query.status) {
      orders = orders.filter((o) => o.status === req.query.status);
    }
    orders = [...orders].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    res.json({ orders });
  });

  router.get('/:id', (req, res) => {
    const order = db.get('orders').find({ id: req.params.id }).value();
    if (!order) return res.status(404).json({ error: 'Order not found.' });
    if (!['staff', 'admin'].includes(req.user.role) && order.userId !== req.user.id) {
      return res.status(403).json({ error: 'You do not have permission to view this order.' });
    }
    res.json({ order });
  });

  router.patch('/:id/status', requireRole('staff', 'admin'), (req, res) => {
    const { status } = req.body || {};
    if (!VALID_STATUSES.includes(status)) {
      return res.status(400).json({ errors: { status: 'Invalid status value.' } });
    }
    const order = db.get('orders').find({ id: req.params.id }).value();
    if (!order) return res.status(404).json({ error: 'Order not found.' });
    if (TERMINAL_STATUSES.includes(order.status)) {
      return res.status(400).json({ error: `Cannot change status of a ${order.status} order.` });
    }
    db.get('orders').find({ id: req.params.id }).assign({ status }).write();
    res.json({ order: db.get('orders').find({ id: req.params.id }).value() });
  });

  return router;
};
