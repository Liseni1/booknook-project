const express = require('express');
const { authenticate, requireRole } = require('../middleware/auth');
const { isValidIsbn } = require('../utils/validate');
const { genId } = require('../utils/helpers');

function validateBook(body, { partial } = {}) {
  const errors = {};
  const touched = (key) => !partial || body[key] !== undefined;

  if (touched('title') && (!body.title || !String(body.title).trim())) {
    errors.title = 'Title is required.';
  }
  if (touched('author') && (!body.author || !String(body.author).trim())) {
    errors.author = 'Author is required.';
  }
  if (touched('category') && (!body.category || !String(body.category).trim())) {
    errors.category = 'Category is required.';
  }
  if (touched('isbn') && (!body.isbn || !isValidIsbn(body.isbn))) {
    errors.isbn = 'Enter a valid 10 or 13 digit ISBN.';
  }
  if (touched('price')) {
    const price = Number(body.price);
    if (!Number.isFinite(price) || price <= 0) errors.price = 'Price must be a number greater than 0.';
  }
  if (touched('stock')) {
    const stock = Number(body.stock);
    if (!Number.isInteger(stock) || stock < 0) errors.stock = 'Stock must be a whole number of 0 or more.';
  }
  return errors;
}

module.exports = function booksRoutes(db) {
  const router = express.Router();

  router.get('/', (req, res) => {
    const { search, category } = req.query;
    let books = db.get('books').value();
    if (category && category !== 'All') {
      books = books.filter((b) => b.category === category);
    }
    if (search) {
      const q = String(search).toLowerCase();
      books = books.filter(
        (b) =>
          b.title.toLowerCase().includes(q) ||
          b.author.toLowerCase().includes(q) ||
          b.isbn.includes(q)
      );
    }
    res.json({ books });
  });

  router.get('/:id', (req, res) => {
    const book = db.get('books').find({ id: req.params.id }).value();
    if (!book) return res.status(404).json({ error: 'Book not found.' });
    res.json({ book });
  });

  router.post('/', authenticate, requireRole('staff', 'admin'), (req, res) => {
    const errors = validateBook(req.body || {});
    if (Object.keys(errors).length) return res.status(400).json({ errors });

    const book = {
      id: genId('b'),
      title: String(req.body.title).trim(),
      author: String(req.body.author).trim(),
      isbn: String(req.body.isbn).trim(),
      category: String(req.body.category).trim(),
      price: Number(req.body.price),
      stock: Number(req.body.stock),
      description: req.body.description ? String(req.body.description).trim() : '',
      coverLetter: String(req.body.title).trim().charAt(0).toUpperCase(),
    };
    db.get('books').push(book).write();
    res.status(201).json({ book });
  });

  router.put('/:id', authenticate, requireRole('staff', 'admin'), (req, res) => {
    const existing = db.get('books').find({ id: req.params.id }).value();
    if (!existing) return res.status(404).json({ error: 'Book not found.' });

    const errors = validateBook(req.body || {}, { partial: true });
    if (Object.keys(errors).length) return res.status(400).json({ errors });

    const updates = { ...req.body };
    if (updates.price !== undefined) updates.price = Number(updates.price);
    if (updates.stock !== undefined) updates.stock = Number(updates.stock);
    if (updates.title) {
      updates.title = String(updates.title).trim();
      updates.coverLetter = updates.title.charAt(0).toUpperCase();
    }
    if (updates.author) updates.author = String(updates.author).trim();
    if (updates.isbn) updates.isbn = String(updates.isbn).trim();
    if (updates.category) updates.category = String(updates.category).trim();
    if (updates.description !== undefined) updates.description = String(updates.description).trim();

    db.get('books').find({ id: req.params.id }).assign(updates).write();
    res.json({ book: db.get('books').find({ id: req.params.id }).value() });
  });

  router.delete('/:id', authenticate, requireRole('admin'), (req, res) => {
    const existing = db.get('books').find({ id: req.params.id }).value();
    if (!existing) return res.status(404).json({ error: 'Book not found.' });
    db.get('books').remove({ id: req.params.id }).write();
    res.status(204).end();
  });

  return router;
};
