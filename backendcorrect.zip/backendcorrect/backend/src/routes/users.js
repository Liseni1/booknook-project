const express = require('express');
const { authenticate, requireRole } = require('../middleware/auth');
const { publicUser } = require('../utils/helpers');

const VALID_ROLES = ['customer', 'staff', 'admin'];

module.exports = function usersRoutes(db) {
  const router = express.Router();
  router.use(authenticate, requireRole('admin'));

  router.get('/', (req, res) => {
    res.json({ users: db.get('users').value().map(publicUser) });
  });

  router.patch('/:id/role', (req, res) => {
    const { role } = req.body || {};
    if (!VALID_ROLES.includes(role)) {
      return res.status(400).json({ errors: { role: 'Invalid role.' } });
    }
    const user = db.get('users').find({ id: req.params.id }).value();
    if (!user) return res.status(404).json({ error: 'User not found.' });

    if (user.role === 'admin' && role !== 'admin') {
      const adminCount = db.get('users').filter({ role: 'admin' }).value().length;
      if (adminCount <= 1) {
        return res.status(400).json({ error: 'Cannot demote the only remaining administrator.' });
      }
    }

    db.get('users').find({ id: req.params.id }).assign({ role }).write();
    res.json({ user: publicUser(db.get('users').find({ id: req.params.id }).value()) });
  });

  return router;
};
